import random
from importlib_resources import files

from psynet.utils import pretty_log_dict
import numpy as np
from statistics import mean

from psynet.utils import pretty_log_dict
from psynet.modular_page import ModularPage, SliderControl
from psynet.js_synth import JSSynth, Note
from psynet.timeline import Event, Trigger

from typing import Union, List, Optional, Dict

from . import scripts


class MelodySliderPage(ModularPage):
    def __init__(
        self,
        label: str,
        starting_values: List[float],
        active_idx: int,
        reference_pitch: float,
        min_value: float,
        max_value: float,
        reference_mode: str,
        dimensions: int,
        text, # JSSynth
        timbre="default", # JSSynth
        default_duration=0, # JSSynth
        default_silence=0, # JSSynth
        text_align="left", # JSSynth
        reverse_scale: Optional[bool] = False,
        minimal_interactions=3,
        time_estimate=None,
        enable_slider_after=0.0,
        slider_start_value=None,
        slider_reference_pitch=None,
        **kwargs,
    ):
        assert 0 <= active_idx < dimensions
        self.active_idx = active_idx
        self.starting_values = starting_values

        if slider_start_value is None:
            slider_start_value = starting_values[active_idx]

        if slider_reference_pitch is None:
            slider_reference_pitch = reference_pitch

        pitches = convert_interval_sequence_to_absolute_pitches(starting_values, reference_pitch, reference_mode)
        sequence = [Note(p) for p in pitches]

        ## ModularPage() parameters
        prompt = JSSynth(
            text=text,
            sequence=sequence,
            timbre=timbre,
            default_duration=default_duration,
            default_silence=default_silence,
            text_align=text_align
        )

        control = SliderControl(
            label=label, start_value=slider_start_value, min_value=min_value, max_value=max_value,
            reverse_scale=reverse_scale, minimal_interactions=minimal_interactions, directional=False)

        ## Load JS script
        js_script = get_script("pitches_by_reference_mode.js")

        events = {
            "playMelody": Event(
                is_triggered_by="sliderChange",
                js=f"""
                    {js_script}
                    var init_intervals = {starting_values};
                    var active_idx = {active_idx};
                    var reference_mode = "{reference_mode}";
                    var reference_pitch = {reference_pitch};
                    pitches_by_reference_mode(init_intervals, active_idx, reference_mode, reference_pitch)
                    psynet.trial.registerEvent("promptStart");
                    """
            ),
            "responseEnable": Event(
                is_triggered_by="promptEnd",
                once=True,
                delay=enable_slider_after,
            ),
            "enableSlider": Event(
                is_triggered_by=["responseEnable", "promptEnd"],
                js="slider.disabled = false;"
            ),
            "disableSlider": Event(
                is_triggered_by="promptStart",
                js="slider.disabled = true;"
            ),
            "trialFinish": Event(is_triggered_by=None),
        }

        super().__init__(
            label=label,
            prompt=prompt,
            control=control,
            events=events,
            time_estimate=time_estimate,
            **kwargs,
        )

    def metadata(self, **kwargs):
        return {
            "prompt": self.prompt.metadata,
            "active_idx": self.active_idx,
            "starting_values": self.starting_values,
        }


def sample_interval_sequence(
        n_int,
        max_interval_size,
        max_melody_pitch_range,
        discrete,
        reference_mode,
):
    """
    Generates a random interval sequence, defining the pitch content of a melody.
    We use this for example for generating random seeds for iterated singing chains.

    Parameters
    ----------
    n_int:
        Number of intervals in the melody.

    max_interval_size:
        Maximum size interval allowed in the melody; see params.py.

    max_melody_pitch_range:
        Maximum pitch range allowed in the melody; see params.py

    discrete:
        If ``True``, the intervals are constrained to take integer values.

    reference_mode:
        Can be ``"first_note"`` or ``"previous_note"``.
        When the ``reference_mode`` is ``"first_note"``, this means that each interval is expressed relative
        to the first note in the melody. For example, a major triad would be expressed as ``[4, 7]``.
        When the ``reference_mode`` is ``"previous_note"``, this means that each interval is expressed relative
        to the previous note in the melody. For example, a major triad would be expressed as ``[4, 3]``.

    Returns
    -------

    A list of intervals, each expressed as numbers.
    """
    n_try = 1e5
    counter = 0
    while counter < n_try:
        candidate = [
            sample_interval(
                max_interval_size,
                discrete,
            )
            for _ in range(n_int)
        ]
        if is_valid_interval_sequence(candidate, n_int, max_interval_size, max_melody_pitch_range, reference_mode):
            return candidate
        counter += 1
    raise RuntimeError(
        "Failed to generate valid interval sequence with the following constraints: "
        + pretty_log_dict(dict(
            n_int=n_int,
            max_interval_size=max_melody_pitch_range,
            reference_mode=reference_mode,
        ))
    )


def sample_interval(max_interval_size, discrete):
    assert max_interval_size >= 0
    if discrete:
        return random.randint(- max_interval_size, max_interval_size)
    else:
        return random.uniform(- max_interval_size, max_interval_size)


def sample_reference_pitch(roving_mean, roving_width):
    return random.uniform(roving_mean - roving_width, roving_mean + roving_width)


def is_valid_interval_sequence(
        intervals,
        n_int,
        max_interval_size,
        max_melody_pitch_range,
        reference_mode,
    ):
    """
    Checks whether an interval sequence is valid according to the constraints
    expressed in the options.
    This can be used, for example, for making sure that sequences stay within bounds in
    serial reproduction experiments.

    Parameters
    ----------

    intervals:
        A list of intervals, with each interval expressed as a number.

    max_interval_size:
        Maximum size interval allowed in the melody; see params.py.

    max_melody_pitch_range:
        Maximum pitch range allowed in the melody; see params.py

    discrete:
        If ``True``, the intervals are constrained to take integer values.

    reference_mode:
        Can be ``"first_note"`` or ``"previous_note"``.
        When the ``reference_mode`` is ``"first_note"``, this means that each interval is expressed relative
        to the first note in the melody. For example, a major triad would be expressed as ``[4, 7]``.
        When the ``reference_mode`` is ``"previous_note"``, this means that each interval is expressed relative
        to the previous note in the melody. For example, a major triad would be expressed as ``[4, 3]``.
    """
    try:
        assert len(intervals) == n_int
        for interval in intervals:
            assert abs(interval) <= max_interval_size
        assert get_melody_pitch_range(intervals, reference_mode) <= max_melody_pitch_range
        return True
    except AssertionError:
        return False


def get_melody_pitch_range(intervals, reference_mode):
    """
    Gets the range of pitches used in an interval sequence.
    """
    example_pitches = convert_interval_sequence_to_absolute_pitches(
        intervals,
        reference_pitch=60,
        reference_mode=reference_mode
    )
    return max(example_pitches) - min(example_pitches)


def convert_interval_sequence_to_absolute_pitches(intervals, reference_pitch, reference_mode):
    """
    Takes an interval sequence and converts it to a set of absolute pitches,
    i.e. MIDI note numbers where 60 corresponds to middle C (C4) and integers correspond to semitones.

    Parameters
    ----------

    intervals:
        A list of intervals, with each interval expressed as a number.

    reference_pitch:
        The reference pitch to use, expressed as a MIDI note number. The interpretation of this pitch
        is determined by the latter ``reference_mode`` argument.

    reference_mode:
        Can be ``"first_note"`` or ``"previous_note"``.
        When the ``reference_mode`` is ``"first_note"``, this means that each interval is expressed relative
        to the first note in the melody. For example, a major triad would be expressed as ``[4, 7]``.
        When the ``reference_mode`` is ``"previous_note"``, this means that each interval is expressed relative
        to the previous note in the melody. For example, a major triad would be expressed as ``[4, 3]``.

    Returns
    -------

    A list of absolute pitches, expressed as MIDI note numbers.
    """
    if reference_mode == "first_note":
        first_note = reference_pitch
        return [first_note] + [interval + reference_pitch for interval in intervals]
    elif reference_mode == "previous_note":
        pitches = [reference_pitch]
        for interval in intervals:
            last_pitch = pitches[-1]
            new_pitch = last_pitch + interval
            pitches.append(new_pitch)
        return pitches
    else:
        raise ValueError(f"Unrecognized reference_mode: {reference_mode}.")


def convert_absolute_pitches_to_interval_sequence(pitches, reference_mode):
    """
    Takes a sequence of absolute pitches and converts it to an interval

    Parameters
    ----------

    pitches:
        A list of absolute pitches, expressed as MIDI note numbers.

    reference_mode:
        Can be ``"first_note"`` or ``"previous_note"``.
        When the ``reference_mode`` is ``"first_note"``, this means that each interval is expressed relative
        to the first note in the melody. For example, a major triad would be expressed as ``[4, 7]``.
        When the ``reference_mode`` is ``"previous_note"``, this means that each interval is expressed relative
        to the previous note in the melody. For example, a major triad would be expressed as ``[4, 3]``.

    Returns
    -------

    A list of absolute pitches, expressed as MIDI note numbers.
    """
    intervals = []
    for i in range(1, len(pitches)):
        pitch = pitches[i]
        if reference_mode == "first_note":
            reference_pitch = pitches[0]
        elif reference_mode == "previous_note":
            reference_pitch = pitches[i - 1]
        else:
            raise ValueError(f"Invalid reference_mode: '{reference_mode}'")
        intervals.append(pitch - reference_pitch)
    return intervals


def as_native_type(x):
    if type(x).__module__ == np.__name__:
        return x.item()
    return x

def diff(x):
    return [j - i for i, j in zip(x[:-1], x[1:])]

def get_singing_error(sung_midi, target_midi, max_mean_interval_error):
    assert len(target_midi) > 1

    target_int = diff(target_midi)
    actual_int = diff(sung_midi)

    if len(target_int) != len(actual_int):
        return {
        "correct_num_notes": False,
        "correct_mean_deviation": False,
        "mean_interval_error_ok": False
        }
    else:
        interval_error = [abs(j - i) for i, j in zip(target_int, actual_int)]
        return {
            "correct_num_notes": True,
            "mean_interval_error": mean(interval_error),
            "mean_interval_error_ok": mean(interval_error) < max_mean_interval_error
        }


def failing_criteria(
        sung_intervals,
        num_target_intervals,
        sung_midi,
        target_midi,
        max_mean_interval_error,
        max_interval_size,
        max_melody_pitch_range,
        reference_mode
):
    """ Perform basic failing criteria for singing production tasks

    Parameters
    ----------

    sung_intervals : list
        A list of the sung intervals, with each interval expressed as a number.
    num_target_intervals : float
        The number of target intervals
    sung_midi : list
        list of midi notes extracted from the sung response
    target_midi : class
        list of midi notes played in the input stimulus
    max_mean_interval_error : float
        maximum value allowed for mean absolute deviation
    max_interval_size:
        Maximum size interval allowed in the melody; see params.py.
    max_melody_pitch_range:
        Maximum pitch range allowed in the melody; see params.py
    reference_mode:
        Can be ``"first_note"`` or ``"previous_note"``.
        When the ``reference_mode`` is ``"first_note"``, this means that each interval is expressed relative
        to the first note in the melody. For example, a major triad would be expressed as ``[4, 7]``.
        When the ``reference_mode`` is ``"previous_note"``, this means that each interval is expressed relative
        to the previous note in the melody. For example, a major triad would be expressed as ``[4, 3]``.

    Returns
    --------

    is_failed : dict
        A dictionary with the output of the failing criteria
    """
    error = get_singing_error(sung_midi, target_midi, max_mean_interval_error)
    valid_interval_sequence = is_valid_interval_sequence(
        sung_intervals,
        num_target_intervals,
        max_interval_size,
        max_melody_pitch_range,
        reference_mode
        )

    failed_options = [
        error["correct_num_notes"],
        # error["mean_interval_error_ok"],
        valid_interval_sequence
    ]
    reasons = [
        (f"Wrong number of sung notes: {len(sung_midi)}  sung out of {len(target_midi)} notes in melody"),
        # "Mean absolute deviation is too large",
        "One interval is too large"
    ]

    if False in failed_options:
        failed = True
        index = failed_options.index(False)
        reason = reasons[index]
    else:
        failed = False
        reason = "All good"
    is_failed = {
        "failed": failed,
        "reason": reason,
        "output_singing_error": error
    }
    return is_failed


def feedback_generator(analysis):
    """ Generate feedback based on performance
    analysis:
        A dictionary with the output of the analysis, including failing criteria

    Returns
    --------

    feedback : dict
        A dictionary with the feedback to return to participants based on their peroformance
    """

    # interval accuracy
    stats = analysis["stats"]
    num_target_mids = len(analysis["target_pitches"])
    num_sung_midis = len(analysis["sung_pitches"])

    too_many_sung_notes = num_target_mids < num_sung_midis
    too_few_sung_notes = num_target_mids > num_sung_midis


    failed_options = [too_many_sung_notes, too_few_sung_notes,]
    reasons = [
    f"You have sung too many notes: the melody had {num_target_mids} notes and you sung {num_sung_midis} notes. Please sing the exact same number of notes that you hear in the melody.",
    f"You have not sung enough notes: the melody had {num_target_mids} notes and you sung {num_sung_midis} notes. Please sing the exact same number of notes that you hear in the melody.",
    ]

    if True in failed_options:
        status = "bad"
        index = failed_options.index(True)
        message = reasons[index]
    elif abs(stats["mean_interval_diff"]) < 0.5:
        status = "perfect"
        message = "Your singing accuracy is Excellent."
    elif stats["direction_accuracy"] == 100:
        status = "ok"
        message = "Your singing accuracy is ok, but you can do better."
    else:
        status = "bad"
        message = "Your singing accuracy is not good. To continue with the experiment, you will need to improve your performance by singing each note in the melody accurately."

    feedback = {
        "status": status,
        "message": message
    }
    return feedback


def get_script(filename):
    """
    Takes a file name or a list of file names as input and returns the corresponding JS scripts
    from the script directory as a string (or list of strings).

    Parameters
    ----------

    filename:
        A string or list of strings

    Returns
    -------

    String or list of strings corresponding to the files that were requested
    """
    if isinstance(filename, list):
        js_scripts = [files(scripts).joinpath(f).read_text() for f in filename]
        return js_scripts
    if isinstance(filename, str):
        js_script = files(scripts).joinpath(filename).read_text()
        return js_script
    else:
        return ValueError("Parameter must be a string or a list of strings corresponding to JS filenames in the script directory")


def get_duration(seq, default_duration=None, default_silence=None):
    """
    Gets the duration of a JSSynth sequence.
    """
    sec = 0.0
    for elt in seq:
        duration = elt["duration"]
        if duration == "default":
            if default_duration is None:
                raise RuntimeError("Need to specify default_duration")
            duration = default_duration

        silence = elt["silence"]
        if silence == "default":
            if default_silence is None:
                raise RuntimeError("Need to specify default_duration")
            silence = default_silence

        sec += duration + silence
    return sec


def midi2freq(midi_number):
    return (440 / 32) * (2**((midi_number - 9) / 12))


def freq2midi(f0):
    if f0 <= 0:
        return 0
    else:
        exp = result=12 * (np.log2(f0) - np.log2(440)) + 69
        if exp < 0:
            return 0 # get's weird log2 values otherwise...
        else:
            return exp
