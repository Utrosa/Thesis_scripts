# iterated singing: long melodies
from statistics import mean
import random
from flask import Markup
import json
import psynet.experiment
import psynet.media
from psynet.modular_page import AudioRecordControl, ModularPage, PushButtonControl, AudioPrompt
from psynet.page import InfoPage, SuccessfulEndPage
from psynet.js_synth import JSSynth, Note, InstrumentTimbre
from psynet.prescreen import HeadphoneTest
from psynet.timeline import (
    Timeline,
    PreDeployRoutine,
    join,
    ProgressDisplay,
    ProgressStage,
    Event,
    switch,
    CodeBlock,
)
from psynet.media import prepare_s3_bucket_for_presigned_urls, make_bucket_public
from psynet.consent import MTurkStandardConsent, MTurkAudiovisualConsent, NoConsent
from psynet.trial.audio import (
    AudioImitationChainNetwork,
    AudioImitationChainNode,
    AudioImitationChainSource,
    AudioImitationChainTrial,
    AudioImitationChainTrialMaker,
)
from psynet.utils import get_logger

logger = get_logger()
# sing4me
from sing4me import singing_extract as sing
from sing_experiments import params, melodies
from sing_experiments.resources import (
    GenderSplit,
    ToneJSVolumeTest,
    SingingCalibration,
    # SingingRecordingTest,
    SingingPerforamnceTest
)
from sing_experiments.questionnaire import standard, hardware_softwware
from psynet.demography.gmsi import GMSI


# functions
def estimate_time_per_trial(
        singing_duration,
        pitch_duration,
        num_pitches,
        added_time
):
    melody_duration = pitch_duration * num_pitches
    time_estimate_trial = singing_duration + melody_duration + added_time
    end_melody = melody_duration + added_time
    return time_estimate_trial, end_melody


# global parameters
DEBUG = False

if DEBUG:
    INITIAL_RECRUITMENT_SIZE = 1
    num_trials_per_participant = 10
    num_trials_per_participant_optional = 10
    num_iterations_per_chain = 4
    num_chains_per_exp = 2
    num_chains_per_exp_optional = 2
    repeat_same_chain = True
else:
    INITIAL_RECRUITMENT_SIZE = 20
    # main
    num_trials_per_participant = 50
    num_chains_per_exp = 100
    num_iterations_per_chain = 10
    repeat_same_chain = False
    # optional (2nd part)
    num_trials_per_participant_optional = 40
    num_chains_per_exp_optional = 50

config = params.singing_2intervals  # 2 intervals
# config = params.singing_long_melodies # 4 intervals
reference_pitch = params.roving_mean

TIMBRE = InstrumentTimbre("piano")
# s3 bucket
BUCKET_NAME = "iterated-singing"
# from psynet.media import make_bucket_public, create_bucket
# create_bucket(BUCKET_NAME)
# make_bucket_public(BUCKET_NAME)

# if using blocking
# BLOCK_ORDERS = [
#     ["tone_js", "raw"],
#     ["raw", "tone_js"],
# ]

# timings
SINGING_DURATION = config["sing_duration"]
END_RECORDING = 1
PITCH_DURATION = params.note_duration + params.note_silence
NUM_PITCHES = config["num_int"] + 1
TIME_ESTIMATE_TRIAL, END_MELODY = estimate_time_per_trial(
    SINGING_DURATION,
    PITCH_DURATION,
    NUM_PITCHES,
    1
)
TIME_ESTIMATE_TRIAL = TIME_ESTIMATE_TRIAL + 5

DESIGN_PARAMS = {
    "num_trials_per_participant": num_trials_per_participant,  # 50 main experiment,
    "num_trials_per_participant_optional": num_trials_per_participant_optional,  # 40 main experiment
    "num_trials_practice_test": 3,
    "num_trials_practice_feedback": 2,
    "num_iterations_per_chain": num_iterations_per_chain,  # 9 main experiment, will result in 10 iterations
    "trials_per_node": 1,  # set to 1 for non-aggregation
    "performance_threshold_main": 0.50,
    "chain_type": "across",
    "num_chains_per_participant": None,
    "recruit_mode": "num_trials",
    "target_num_participants": None,
    "num_chains_per_exp": int(num_chains_per_exp),
    "num_chains_per_exp_optional": int(num_chains_per_exp_optional),  # 50 for main experiment
    "repeat_same_chain": repeat_same_chain
}


# iterated reproduction
class CustomTrial(AudioImitationChainTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial"}

    time_estimate = TIME_ESTIMATE_TRIAL

    def show_trial(self, experiment, participant):
        definition = self.definition

        # counting trials
        current_trial = self.position + 1
        if self.phase == "practice_feedback":
            total_num_trials = DESIGN_PARAMS["num_trials_practice_feedback"]
        elif self.phase == "practice_test":
            total_num_trials = DESIGN_PARAMS["num_trials_practice_test"]
        elif self.phase == "experiment_optional":
            total_num_trials = DESIGN_PARAMS["num_trials_per_participant_optional"]
        else:
            total_num_trials = DESIGN_PARAMS["num_trials_per_participant"]
        show_current_trial = f'<br><br>Trial number {current_trial} out of {total_num_trials} trials.'
        message = Markup(
            f"""
            <h3>Imitate the melody</h3>
            <hr>
            <b><b>This melody has {NUM_PITCHES} notes:</b></b> 
            Sing each note back to the syllable 'Ta'<br>
            <i>leave a silent gap between the notes</i>
            <br><br>
            {show_current_trial}
            <hr>
            """
        )

        return ModularPage(
            "singing_tone_js",
            JSSynth(
                message,
                [Note(pitch) for pitch in definition["target_pitches"]],
                timbre=TIMBRE,
                default_duration=params.note_duration,
                default_silence=params.note_silence,
            ),
            AudioRecordControl(
                duration=SINGING_DURATION,
                s3_bucket=BUCKET_NAME,
                public_read=True,
                show_meter=False,
                controls=False,
                auto_advance=False,
            ),
            time_estimate=TIME_ESTIMATE_TRIAL,
            events={
                "promptStart": Event(is_triggered_by="trialStart"),
                "recordStart": Event(is_triggered_by="promptEnd", delay=0.25)
            },
            progress_display=ProgressDisplay(
                stages=[
                    ProgressStage(END_MELODY, "Listen to the melody...", "orange"),
                    ProgressStage(SINGING_DURATION, "Recording...SING THE MELODY!", "red"),
                    ProgressStage(END_RECORDING, "Finished (click next when ready).",
                                  "green",
                                  persistent=True
                                  ),
                ],
            ),
        )

    def analyze_recording(self, audio_file: str, output_plot: str):
        if self.phase.startswith("experiment"):
            save_plot = True
        else:
            save_plot = False

        raw = sing.analyze(
            audio_file,
            config,
            target_pitches=self.definition["target_pitches"],
            plot_options=sing.PlotOptions(
                save=save_plot, path=output_plot, format="png"
            ),
        )
        raw = [
            {key: melodies.as_native_type(value) for key, value in x.items()} for x in raw
        ]
        sung_pitches = [x["median_f0"] for x in raw]
        sung_intervals = melodies.convert_absolute_pitches_to_interval_sequence(
            sung_pitches,
            "previous_note"
        )
        target_intervals = melodies.convert_absolute_pitches_to_interval_sequence(
            self.definition["target_pitches"],
            "previous_note"
        )
        pitch_heights = melodies.convert_absolute_pitches_to_pitch_heights(
            sung_pitches,
            self.definition["reference_pitch"]
        )
        stats = sing.compute_stats(
            sung_pitches,
            self.definition["target_pitches"],
            sung_intervals,
            target_intervals
        )
        is_failed = melodies.failing_criteria(
            sung_intervals,
            sung_pitches,
            self.definition["reference_pitch"],
            config["num_int"],
            config["max_interval_size"],
            config["max_melody_pitch_range"],
            config["reference_mode"],
            stats,
            config["max_abs_interval_error_treshold"],
            config["max_pitch_height"]
        )
        return {
            "failed": is_failed["failed"],
            "reason": is_failed["reason"],
            "reference_pitch": self.definition["reference_pitch"],
            "target_pitches": self.definition["target_pitches"],
            "target_intervals": target_intervals,
            "sung_pitches": sung_pitches,
            "sung_intervals": sung_intervals,
            "pitch_heights": pitch_heights,
            "raw": raw,
            "save_plot": save_plot,
            "stats": stats,
        }


class CustomTrialPractice(CustomTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial_practice"}

    wait_for_feedback = True
    time_estimate = TIME_ESTIMATE_TRIAL - 2

    def gives_feedback(self, experiment, participant):
        return True

    def show_feedback(self, experiment, participant):
        output_analysis = json.loads(self.details["analysis"])
        num_sung_pitches = len(output_analysis["sung_pitches"])
        if num_sung_pitches == NUM_PITCHES:
            return InfoPage(
                Markup(
                    f"""
                    <h3>Excellent!</h3>
                    <hr>
                    You sung {num_sung_pitches} out of {NUM_PITCHES} notes.
                    <br><br>
                    Keep up this performance throughout the experiment and you will get the full bonus.
                    <hr>
                    <img style="width:50%" src="/static/images/happy.png"  alt="happy">
                    """
                ),
                time_estimate=5
            )
        elif num_sung_pitches == (NUM_PITCHES - 1) or num_sung_pitches == (NUM_PITCHES - 1):
            return InfoPage(
                Markup(
                    f"""
                    <h3>Not so good..</h3>
                    <hr>
                    You sung {num_sung_pitches} out of {NUM_PITCHES} notes.
                    <br>
                    Please try to do one or more of the following:
                    <ol><li>Sing the exact same number of notes that you hear in the melody.</li>
                        <li>Leave a silent gap between the notes.</li>
                        <li>Sing each note loud, clearly, and for long enough (about 1 second each).</li>
                        <li>Make sure you computer microphone is working and you are in a quiet environment.</li>
                    </ol>
                    <br><br>
                    <b><b>If you don't improve your performance, the experiment will terminate.</b></b>
                    <hr>
                    <img style="width:50%" src="/static/images/neutral.png"  alt="neutral">
                    """
                ),
                time_estimate=5
            )
        else:
            return InfoPage(
                Markup(
                    f"""
                    <h3>Bad..</h3>
                    <hr>
                    You sung {num_sung_pitches} out of {NUM_PITCHES} notes.
                    <br><br>
                    Please try to do one or more of the following:
                    <ol><li>Sing the exact same number of notes that you hear in the melody.</li>
                        <li>Leave a silent gap between the notes.</li>
                        <li>Sing each note loud, clearly, and for long enough (about 1 second each).</li>
                        <li>Make sure you computer microphone is working and you are in a quiet environment.</li>
                    </ol>
                    <br><br>
                    <b><b>If you don't improve your performance, the experiment will terminate.</b></b>
                    <hr>
                    <img style="width:50%" src="/static/images/sad.png"  alt="sad">
                    """
                ),
                time_estimate=5
            )


class CustomNetwork(AudioImitationChainNetwork):
    __mapper_args__ = {"polymorphic_identity": "custom_network"}

    run_async_post_grow_network = False
    s3_bucket = BUCKET_NAME


class CustomNode(AudioImitationChainNode):
    __mapper_args__ = {"polymorphic_identity": "custom_node"}

    def summarize_trials(self, trials: list, experiment, participant):
        sung_pitches = [trial.analysis["sung_pitches"] for trial in trials]
        reference_pitch = [trial.analysis["reference_pitch"] for trial in trials]
        # retrieve url
        # recording_url = [trial.answer["url"] for trial in trials]
        # recording_url_as_string = "".join([str(item) for item in recording_url])

        return dict(
            reference_pitch=reference_pitch.pop(0),
            target_pitches=[mean(x) for x in zip(*sung_pitches)],
            trial_type="node_trial"
            # recording_url=recording_url_as_string
        )


class CustomSource(AudioImitationChainSource):
    __mapper_args__ = {"polymorphic_identity": "custom_source"}

    def generate_seed(self, network, experiment, participant):
        # select register based on trial_maker_id
        register = "male" if self.network.trial_maker_id.startswith("male") else "female"
        # trial_type = "tonejs" if self.network.trial_maker_id.startswith("tone_js") else "raw_recording"

        if self.network.phase == "practice":  # select pitch_height based on  phase
            max_pitch_height = 4.5
        else:
            max_pitch_height = config["max_pitch_height_seed"]

        # reference_pitch = melodies.sample_reference_pitch( # no need to rove refernece_pitch
        #     params.roving_mean[register],
        #     params.roving_width["default"]
        # )

        target_pitches = melodies.sample_absolute_pitches(
            reference_pitch=reference_pitch[register],
            max_pitch_height=max_pitch_height,
            num_int=config["num_int"]
        )

        return dict(
            register=register,
            reference_pitch=reference_pitch[register],
            max_pitch_height=max_pitch_height,
            target_pitches=target_pitches,
            trial_type="source_trial",
        )


# Experiment
Welcome = InfoPage(
    Markup(
        """
        <h3>Welcome</h3>
        <hr>
        In this experiment, you will hear melodies and be asked to sing them back.
        <br><br>
        You must perform the experiment using <b><b>headphones with working microphone</b></b>.
        <hr>
        """
    ),
    time_estimate=3
)


class SingingImitationTrialMakerPractice(AudioImitationChainTrialMaker):
    performance_check_type = "performance"
    performance_check_threshold = 0
    give_end_feedback_passed = False


class SingingImitationTrialMakerTest(AudioImitationChainTrialMaker):
    performance_check_type = "performance"
    performance_check_threshold = 0.5
    give_end_feedback_passed = False


class ImitationChainTrialMakerMain(AudioImitationChainTrialMaker):
    give_end_feedback_passed = False
    performance_check_type = "performance"
    performance_check_threshold = DESIGN_PARAMS["performance_threshold_main"]

    def check_fail_logic(self):
        return join(
            InfoPage(
                Markup(f"""
                    <h3>You have completed the experiment</h3>
                    <br><br>
                    Thank you for your participation!
                    """
                       ),
                time_estimate=5),
            SuccessfulEndPage())


practice_instructions = join(
    InfoPage("We can now start with the main singing task, please pay attention to the instructions.", time_estimate=2),
    InfoPage(Markup(f"""
            <h3>Instructions</h3>
            <hr>
            In each trial, you will hear a melody with <b><b>{NUM_PITCHES} notes.</b></b>
            <br><br>
            Your goal is to imitate the melody back as accurately as possible, 
            singing each note to the syllable 'Ta'.
            <br><br>

            <hr>
            """
                    ),
             time_estimate=3
             ),
    InfoPage(Markup(f"""
           <h3>Attention</h3>
           <hr>
           We will monitor your performance and give you feedback after each trial.<br><br> 
           <b><b>The final bonus will depend on your singing performance!</b></b>
           <hr>
           Click <b>next</b> to start the practice.
           """
                    ),
             time_estimate=3
             )
)

singing_practice_male = join(
    SingingImitationTrialMakerPractice(
        id_="male_sing_feedback",
        network_class=CustomNetwork,
        trial_class=CustomTrialPractice,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_feedback",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=False,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
    InfoPage(
        Markup(f"""
        <h3>Singing test</h3>
        <hr>
        You will now take a singing test. The task is the same as before.
        <br><br>
        <b><b>If you fail the test, the experiment will terminate here</b></b>
        <hr>
        """
               ),
        time_estimate=3
    ),
    SingingImitationTrialMakerTest(
        id_="male_sing_test",
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_test",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=True,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
)

singing_practice_female = join(
    SingingImitationTrialMakerPractice(
        id_="female_sing_feedback",
        network_class=CustomNetwork,
        trial_class=CustomTrialPractice,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_feedback",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=False,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
    InfoPage(
        Markup(f"""
        <h3>Singing test</h3>
        <hr>
        You will now take a singing test. The task is the same as before.
        <br><br>
        <b><b>If you fail the test, the experiment will terminate here</b></b>
        <hr>
        """
               ),
        time_estimate=3
    ),
    SingingImitationTrialMakerTest(
        id_="female_sing_test",
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_test",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=True,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
)

main_instructions = join(
    InfoPage(
        Markup(
            """
            Congratulations, we now move on to the main singing task.
            """
        ),
        time_estimate=3
    ),
    InfoPage(
        Markup(
            f"""
            <h3>Main singing task</h3>
            <hr>
            Like before, in each trial you will hear a melody with {NUM_PITCHES} notes. 
            <br><br>
            <b><b>Your goal is to imitate the melody singing the {NUM_PITCHES} notes to the syllable 'Ta'.</b></b>
            <br><br>
            You will take a total of {DESIGN_PARAMS["num_trials_per_participant"]} trials.
            <br><br>
            <hr>
            """
        ),
        time_estimate=5,
    ),
    InfoPage(Markup(f"""
           <h3>Attention</h3>
           <hr>
            We will analyse your performance after each trial:<br> 
            <b><b>If your performance is bad, the experiment will terminate.</b></b> <br><br>
            On the other hand, good performance will be rewarded with the full bonus: <br>
            <b><b>The best strategy is to sing carefully and as accurately as possible in all trials.</b></b>
            <hr>
            Click <b>next</b> to start singing!
            """
                    ),
             time_estimate=3
             )
)


def copy_main_trialmaker(id, num_trials, num_chains):
    trialmaker = ImitationChainTrialMakerMain(
        id_=id,
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="experiment",
        chain_type=DESIGN_PARAMS["chain_type"],
        num_trials_per_participant=num_trials,
        num_iterations_per_chain=DESIGN_PARAMS["num_iterations_per_chain"],
        num_chains_per_participant=None,
        num_chains_per_experiment=num_chains,  # set to None if chain_type="within"
        trials_per_node=DESIGN_PARAMS["trials_per_node"],
        balance_across_chains=False,
        check_performance_at_end=True,
        check_performance_every_trial=False,
        propagate_failure=False,
        recruit_mode=DESIGN_PARAMS["recruit_mode"],
        target_num_participants=DESIGN_PARAMS["target_num_participants"],
        allow_revisiting_networks_in_across_chains=DESIGN_PARAMS["repeat_same_chain"],
    )
    return trialmaker


singing_main_male = copy_main_trialmaker(
    "male_singing_main",
    DESIGN_PARAMS["num_trials_per_participant"],
    DESIGN_PARAMS["num_chains_per_exp"]
)

singing_main_female = copy_main_trialmaker(
    "female_singing_main",
    DESIGN_PARAMS["num_trials_per_participant"],
    DESIGN_PARAMS["num_chains_per_exp"]
)

singing_optional_male = copy_main_trialmaker(
    "male_singing_optional",
    DESIGN_PARAMS["num_trials_per_participant_optional"],
    DESIGN_PARAMS["num_chains_per_exp_optional"]
)

singing_optional_female = copy_main_trialmaker(
    "female_singing_optional",
    DESIGN_PARAMS["num_trials_per_participant_optional"],
    DESIGN_PARAMS["num_chains_per_exp_optional"]
)

continue_to_second_block = join(
    ModularPage(
        "continue_to_second_block",
        Markup(
            f"""
            <h3>Your singing performance was very good.</h3>
            <hr>
            We would like to give you the opportunity to take more trials and earn more money.
            <br><br>
            If you say <b><b>YES</b></b>, you will be asked to perform the same task as previously in 
            {DESIGN_PARAMS["num_trials_per_participant_optional"]} additional trials, 
            and will be paid proportionally.<br><br>
            If you say <b><b>NO</b></b>, you will be directed to the end of the experiment and be paid your bonus.
            <br><br>
            Would you like to take {DESIGN_PARAMS["num_trials_per_participant_optional"]} more singing trials?
            <hr>
            """
        ),
        PushButtonControl(
            labels=["Yes", "No"],
            choices=["Yes", "No"],
            arrange_vertically=False),
        time_estimate=3
    ),
    CodeBlock(lambda experiment, participant: participant.var.set("continue_to_second_block", participant.answer)
              )
)


# timeline
class Exp(psynet.experiment.Experiment):
    timeline = Timeline(
        PreDeployRoutine(
            "make_bucket_public",
            make_bucket_public,
            {"bucket_name": BUCKET_NAME}
        ),
        PreDeployRoutine(
            "prepare_s3_bucket_for_presigned_urls",
            prepare_s3_bucket_for_presigned_urls,
            {"bucket_name": BUCKET_NAME, "public_read": True, "create_new_bucket": True}
        ),
        # NoConsent(),
        MTurkStandardConsent(),
        MTurkAudiovisualConsent(),
        Welcome,
        # HeadphoneTest(),
        # InfoPage("You passed the headphone screening task! Congratulations.", time_estimate=2),
        # CodeBlock(
        #     lambda participant: participant.var.set(
        #         "block_orders", random.sample(BLOCK_ORDERS, 1)[0]
        #     )
        # ),
        GenderSplit,
        SingingCalibration(),
        ToneJSVolumeTest(),
        switch(
            "split_by_gender",
            lambda experiment, participant: participant.var.gender,
            {
                "male": SingingPerforamnceTest(  # currently this is set to 6 tials and 3 minimum correct to pass
                    label="performance_test_male_label",
                    participant_singing_register="male",
                    trial_maker_id="performance_test_male"
                ),
                "female": SingingPerforamnceTest(
                    label="performance_test_female_label",
                    participant_singing_register="female",
                    trial_maker_id="performance_test_female"
                ),
            },
            fix_time_credit=False
        ),
        practice_instructions,
        switch(
            "split_by_gender",
            lambda experiment, participant: participant.var.gender,
            {
                "male": singing_practice_male,
                "female": singing_practice_female,
            },
            fix_time_credit=False
        ),
        main_instructions,
        switch(
            "split_by_gender",
            lambda experiment, participant: participant.var.gender,
            {
                "male": singing_main_male,
                "female": singing_main_female,
            },
            fix_time_credit=False
        ),
        InfoPage("Congratulations, you finished the main singing task.", time_estimate=2),
        GMSI(label="gmsi_2", subscales=["Musical Training"]),
        hardware_softwware,
        standard,
        continue_to_second_block,
        switch(
            "continue_to_second_block",
            lambda experiment, participant: participant.var.continue_to_second_block,
            {
                "Yes": InfoPage(
                    Markup(
                        f"""
                           <h3>Main singing task</h3>
                           <hr>
                           You will take {DESIGN_PARAMS["num_trials_per_participant_optional"]}  singing trials,
                           similar to the ones before.
                           <br><br>
                           Remember, to get the full bonus, sing as accurately as possible in all trials.
                           <hr>
                           Click <b>next</b> to start singing!
                           """),
                    time_estimate=5
                ),
                "No": SuccessfulEndPage(),
            },
            fix_time_credit=False
        ),
        switch(
            "split_by_gender_optional",
            lambda experiment, participant: participant.var.gender,
            {
                "male": singing_optional_male,
                "female": singing_optional_female,
            },
            fix_time_credit=False
        ),
        SuccessfulEndPage(),
    )

    def __init__(self, session=None):
        super().__init__(session)
        self.initial_recruitment_size = INITIAL_RECRUITMENT_SIZE
