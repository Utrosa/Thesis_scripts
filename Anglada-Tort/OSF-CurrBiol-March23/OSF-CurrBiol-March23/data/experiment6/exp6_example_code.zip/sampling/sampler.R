# sample stimuli for dense rating melodic consonance experiment

library(tidyverse)
library(cowplot)
source("utils.R")

# parameters
roving_mean = 55
roving_width = 2.5
max_pitch_height = 9.5
num_int = 1
BW = 0.25

# example
sample_pitches(roving_mean, roving_width, max_pitch_height, num_int)


################################################################################
# Sample stimuli: pitch mode
################################################################################

# sample continuously from the space
iterations = 5000

data_sampled = sample_stimuli_pitch_mode(
  roving_mean, 
  roving_width, 
  max_pitch_height,
  num_int,
  iterations,
  round_pitches = FALSE
) 

visualize_distributions(data_sampled)


################################################################################
# Sample stimuli: pitch mode + blocking
################################################################################

# sample using blocking by reference pitch
N_BLOCKS = 100
N_ITEATIONS = 50
# 100 * 50 = 5,000 stimuli

data_sampled = sample_stimuli_pitch_mode_blocking(
  # roving_mean, 
  roving_mean,
  roving_width, 
  max_pitch_height,
  num_int,
  N_ITEATIONS,
  N_BLOCKS)  %>% 
  mutate(block_str = paste0("block_",block_n))

visualize_distributions(data_sampled)


################################################################################
# Sample stimuli: first interval mode
################################################################################
# parameters
roving_mean = 55
roving_width = 2.5
max_interval_size = 13.5
num_int = 1
BW = 0.25

data_sampled = sample_stimuli_first_interval_mode(
  roving_mean, 
  roving_width, 
  max_interval_size,
  num_int,
  iterations = 5000
) 

visualize_distributions(data_sampled)


################################################################################
# Generate stimuli
################################################################################
data_sampled1 = sample_stimuli_pitch_mode(
  roving_mean, 
  roving_width, 
  max_pitch_height,
  num_int,
  iterations,
  round_pitches = FALSE
) 

data_sampled2 = sample_stimuli_pitch_mode(
  roving_mean, 
  roving_width, 
  max_pitch_height,
  num_int,
  iterations,
  round_pitches = FALSE
) 
data_sampled3 = sample_stimuli_pitch_mode(
  roving_mean, 
  roving_width, 
  max_pitch_height,
  num_int,
  iterations,
  round_pitches = FALSE
) 

data_sampled_all = as_tibble(rbind(data_sampled1, data_sampled2, data_sampled3))

visualize_distributions(data_sampled1)
visualize_distributions(data_sampled2)
visualize_distributions(data_sampled3)
visualize_distributions(data_sampled_all)

# save
# write_csv(data_sampled1, "melodic_consonance_5K_batch1.csv")
# write_csv(data_sampled2, "melodic_consonance_5K_batch2.csv")
# write_csv(data_sampled3, "melodic_consonance_5K_batch3.csv")

# load
data_sampled1 = read_csv("melodic_consonance_5K_batch1.csv") %>%  select(-pitches)
data_sampled2 = read_csv("melodic_consonance_5K_batch2.csv") %>%  select(-pitches)
data_sampled3 = read_csv("melodic_consonance_5K_batch3.csv") %>%  select(-pitches)

data_sampled_all = as_tibble(rbind(data_sampled1, data_sampled2, data_sampled3))

a = visualize_distributions(data_sampled1)
b = visualize_distributions(data_sampled2)
c = visualize_distributions(data_sampled3)
d = visualize_distributions(data_sampled_all)

ggsave("distribution_batch1_5k.png", a, dpi=300, bg = "white")

################################################################################
# create plot of initial melodies
###############################################################################
int1 = runif(n = 500, min = -15, max = 15)
int2 = runif(n = 500, min = -15, max = 15)

data = tibble(int1 = int1, int2 = int2)

interval_range = c(-15,15)
vertical.lines = seq(from=min(interval_range), to=max(interval_range), by = 1)

plot = ggplot(data, aes(x=int1, y=int2)) + geom_point() +
  scale_x_continuous(breaks=seq(interval_range[[1]],interval_range[[2]],1),limits=c(interval_range[[1]],interval_range[[2]])) +
  scale_y_continuous(breaks=seq((interval_range[[1]]),interval_range[[2]],1),limits=c(interval_range[[1]],interval_range[[2]])) +
  labs(fill = NULL,x="Interval 1",y="Interval 2") +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "darkred") +
  geom_vline(xintercept=0, linetype="dashed", color = "darkred") +
  theme_classic() +
  theme(aspect.ratio=1,
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        axis.title.y = element_blank(),
        axis.title.x = element_blank(),
        legend.position = "none") 

ggsave("plot_sampling.pdf", 
       plot,
       # height = 7, width = 10,
       height = 20, width = 20,
       units = "cm",
       dpi=300)

