library(dplyr)
library(tidyverse)
library(jsonlite)

set.seed(1)

unpack <- function(label, dir = tempfile(pattern = "dir")) {
  zip_file <- file.path("data", 
                        paste0(label, "-data.zip"))
  if (!file.exists(zip_file))
    stop("input file ", zip_file, " does not exist")
  
  files <- list(
    root = dir,
    data = file.path(dir, "data")
  )
  
  extract <- function(zip_file, dir) {
    message("Extracting ", zip_file, " into ", dir, "...")
    unzip(zip_file, exdir = dir)
  }
  
  extract(zip_file, files$root)
  
  files
}


get_config <- function(files) {
  config <- tibble(raw = readLines(files$config)) %>% 
    filter(grepl("=", raw)) %>% 
    mutate(
      key = gsub(" = .*", "", raw),
      value = gsub(".* = ", "", raw)
    ) %>% {
      set_names(as.list(.$value), .$key)
    }
  
  config
}

load_raw_data <- function(files) {
  message("Loading raw data...")
  tibble(
    path = list.files(files$data, full.names = TRUE),
    file = basename(path),
    id = gsub("\\.csv", "", file),
    data = map(path, read_csv, col_types = cols()) #, guess_max = 21474836)
  ) %>% {
    set_names(.$data, .$id)
  }
}

process_responses <- function(raw) {
  responses <- raw$info %>% 
    filter(type=="custom_trial") %>%
    filter(property3==FALSE & failed==FALSE) #remove repeat and failed trials
  
  responses <- responses[,c("origin_id","property1","details","contents")] 
  
  responses <- responses %>%
    mutate(response_id = as.vector(sapply(details,extract_property,"response_id")),
           chord_spec = as.vector(sapply(responses$contents,extract_property,"chord")),
           rating = unname(as.vector(sapply(details,extract_property,"answer"))))
  
  responses <- subset(responses, select = -c(contents,details))
  
  # include years of musical experience
  participants <- raw$participant
  questions <- raw$question 
  valid_participants <- participants %>% filter(failed==FALSE)
  valid_questions <- questions %>% filter(participant_id %in% valid_participants$id)
  musical_experience <- valid_questions %>% 
    filter(question == "years_playing_music") %>%
    mutate(response = sapply(response,as.numeric)) %>%
    filter(response < 100)
  responses <- responses %>% mutate(musical_exp = sapply(property1,get_musical_experience,musical_experience))
  
  responses
  
}

extract_property <- function(json,key){
  if (key == "chord"){
    property <- toJSON(fromJSON(json)$chord)
  } else {
    property <- fromJSON(json)[[key]]
  }
  property
}

process_intervals <- function(responses){
  
  responses <- responses[!sapply(responses$rating,is.null),] 
  
  nresp <- nrow(responses)
  ratings <- data.frame()
  
  for (i in 1:nresp){
    
    current_resp <- responses[i,]
    current_chord <- fromJSON(current_resp$chord_spec)$intervals
    
    for (j in 1:length(current_chord)){
      df <- data.frame("resp_id" = current_resp$response_id[[1]],
                       "origin_id" = current_resp$origin_id[[1]],
                       "participant_id" = current_resp$property1[[1]],
                       "musical_exp" = current_resp$musical_exp[[1]],
                       "parameter" = paste0("v",toString(j)),
                       "value" = current_chord[[j]],
                       "rating" = current_resp$rating[[1]]) 
      
      block <- fromJSON(current_resp$chord_spec)$block
      synth <- fromJSON(current_resp$chord_spec)$synth
      
      if (is.null(block)){
        block <- "default"
      }
      
      df <- df %>% mutate(block = block, synth = synth)
      
      ratings <- rbind(ratings,df)
      
    }
  }
  
  
  ratings <- ratings %>%
    pivot_wider(names_from = parameter,
                values_from = value) 
  
  ratings <- ratings[!duplicated(ratings["origin_id"]),] #remove duplicate ratings
  
  ratings
}

summarize_experiment_costs_and_demographics <- function(raw){
  participants <- raw$participant
  questions <- raw$question 

  valid_participants <- participants %>% filter(failed==FALSE)
  valid_questions <- questions %>% filter(participant_id %in% valid_participants$id)
  
  age_list <- valid_questions %>% filter(question == "age")
  age_list <- sapply(age_list$response,fromJSON)
  age_list <- as.vector(sapply(age_list,as.numeric))
  age_list <- age_list[!is.na(age_list)]
  age_list[age_list > 1900] <- 2022 - age_list[age_list > 1900]
  
  musical_experience <- valid_questions %>% filter(question == "years_playing_music") 
  musical_experience <- sapply(musical_experience$response,fromJSON)
  musical_experience <- as.vector(sapply(musical_experience,as.numeric))
  musical_experience <- musical_experience[!is.na(musical_experience)]
  
  musical_experience <- musical_experience[musical_experience < 100]
  
  gender_list <- valid_questions %>% filter(question == "gender")
  gender_list <- gender_list %>% 
    group_by(response) %>%
    summarise(n = n())
  
  exp_summary <- list()
  
  exp_summary$cost <- sum(participants$base_pay,na.rm=TRUE) + sum(participants$bonus,na.rm=TRUE)
  
  exp_summary$num_of_participants <- nrow(valid_participants)
  
  exp_summary$age$average <- mean(age_list, na.rm = TRUE)
  exp_summary$age$sd <- sd(age_list, na.rm = TRUE)
  
  exp_summary$musical_experience$average <- mean(musical_experience, na.rm = TRUE)
  exp_summary$musical_experience$sd <- sd(musical_experience, na.rm = TRUE)
  
  exp_summary$gender <- gender_list
  
  tot_list = list()
  tot_list$age_list <- age_list
  tot_list$musical_experience_list <- musical_experience
  
  to_return <- list()
  
  to_return$summary <- exp_summary
  to_return$full <- tot_list
  
  to_return
  
}

process_mixed <- function(responses,dname1,dname2){
  responses <- responses[!sapply(responses$rating,is.null),] 
  
  nresp <- nrow(responses)
  ratings <- data.frame()
  
  for (i in 1:nresp){
    
    current_resp <- responses[i,]
    
    
    current_chord <- fromJSON(current_resp$chord_spec)
    vals <- c(current_chord[[dname1]],current_chord[[dname2]])
    dnames <- c(dname1,dname2)
    
    for (j in 1:length(dnames)){
      df <- data.frame("resp_id" = current_resp$response_id[[1]],
                       "origin_id" = current_resp$origin_id[[1]],
                       "participant_id" = current_resp$property1[[1]],
                       "musical_exp" = current_resp$musical_exp[[1]],
                       "parameter" = dnames[[j]],
                       "value" = vals[[j]],
                       "rating" = current_resp$rating[[1]]) #set to 1 for density
      
      ratings <- rbind(ratings,df)
      
    }
  }
  
  ratings <- ratings %>%
    pivot_wider(names_from = parameter,
                values_from = value) 
  
  ratings <- ratings[!duplicated(ratings["origin_id"]),] #remove duplicate ratings
  
  ratings
}

#####################################################################################
################################# START HERE ########################################
#####################################################################################

experiment_label <- "dyh3dd" # Choose experiment zip file, should be in /data folder
MODE = "dyad" # Can be either dyad or rolloff depending on the experiment (dyads, or rolloff + dyads)

files <- unpack(experiment_label)
raw <- load_raw_data(files)

experiment_summary <- summarize_experiment_costs_and_demographics(raw)

if (MODE == "dyad") {
  
  responses <- process_responses(raw)
  ratings <- process_intervals(responses) 
  data_to_save <- subset(ratings, select = c(participant_id,musical_exp,v1,rating))
  
} else if (MODE == "rolloff") {
  
  responses <- process_responses(raw)
  ratings <- process_mixed(responses, "intervals", "rolloff")
  data_to_save <- subset(ratings, select = c(participant_id,musical_exp,intervals,rolloff,rating))
  
}

write.csv(data_to_save, "csv-export/example_export.csv", row.names = FALSE)

experiment_summary