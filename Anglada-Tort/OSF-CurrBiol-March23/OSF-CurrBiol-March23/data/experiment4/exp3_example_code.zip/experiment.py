##########################################################################################
# Imports
##########################################################################################
from flask import Markup
from statistics import mean
import random
import numpy as np
import psynet.experiment
from psynet.consent import MainConsent, AudiovisualConsent, OpenScienceConsent, NoConsent
from psynet.page import InfoPage, SuccessfulEndPage
from psynet.timeline import (
    Timeline,
    join,
    ProgressDisplay,
    ProgressStage,
    CodeBlock,
    conditional
)
from psynet.utils import get_logger
from psynet.prescreen import HeadphoneTest
from psynet.trial.imitation_chain import (
    ImitationChainNetwork,
    ImitationChainNode,
    ImitationChainSource,
    ImitationChainTrial,
    ImitationChainTrialMaker,
)
from psynet.trial.dense import (
    Condition,
    ConditionList,
    Dimension,
    DenseTrialMaker,
    SliderCopyTrial,
)
from dallinger.models import Info
# sing4me
from sing_experiments import melodies
from sing_experiments.resources import (
    ToneJSVolumeTest,
    SingingCalibration,
    select_timbre,
    estimate_time_per_trial,
    SingingPerformanceTest
)
from sing_experiments.params import singing_2intervals
from sing_experiments.questionnaire import BasicDemography, Feedback
from psynet.demography.gmsi import GMSI
from . import psychophysics
# logger
logger = get_logger()


##########################################################################################
# global params
##########################################################################################
DEBUG = False
DESIGN = "across"

TIME_ESTIMATE = 3

# melodies
NUM_INT = 1
# MAX_ABS_INT_ERROR_ALLOWED = 5.5
MAX_INT_SIZE = 15  # first pilot = 7.5; second pilot = 15
SLIDER_WIDTH = MAX_INT_SIZE / 2

# singing
REFERENCE_MODE = "previous_note"  # pitch_mode vs previous_note vs first_note
config = singing_2intervals  # params singing extraction (from sing4me)
roving_width = 2.5
roving_mean = dict(
    default=55,
    low=49,
    high=61
    )
roving_mean = roving_mean["default"]

# timbre
note_duration_tonejs, note_silence_tonejs, TIMBRE = select_timbre("complex_mid_ISI_long")
PITCH_DURATION = note_duration_tonejs + note_silence_tonejs


PARAMS = dict(
    slider_width=SLIDER_WIDTH,
    slider_jitter=SLIDER_WIDTH/2,
    max_trial_bonus=0.05,
    bonus_threshold_semitones=1,
    inter_stimulus_interval=1.25,  # duration of the silent gap between melodies in e.g. 2AFC tasks
    transpose_within_trial_min_step_size=0.0,
    transpose_within_trial_max_step_size=roving_width,
    allow_slider_outside_range=True,
    retention_interval=1.0,
    pitch_reference_mode=REFERENCE_MODE,
    max_melody_pitch_range=999,  # deactivated
    roving_mean=roving_mean,
    roving_width=roving_width,
    note_duration=note_duration_tonejs,
    note_silence=note_silence_tonejs,
    transpose_within_trial=True,
    max_interval_size=MAX_INT_SIZE,
    min_slider_interactions=3
)


PARAMS["dimensions"] = [
    Dimension(
        f"Interval {i + 1}",
        min_value=-PARAMS["max_interval_size"],
        max_value=PARAMS["max_interval_size"]
    )
    for i in range(NUM_INT)
]

CONDITIONS = ConditionList(
    "intervals",
    conditions=[Condition(PARAMS)],
)

if DEBUG:
    INITIAL_RECRUITMENT_SIZE = 10
    NUM_TRIALS_PARTICIPANT = 50
    MAIN_PERFORMANCE_THRESH = 0
    MAX_NUM_FAILED_TRIALS_ALLOWED = 2
    # all
    NUM_ITERATIONS = 3
    NUM_TRIALS_NODE = 3
    # across
    NUM_CHAINS_EXPERIMENT = 5
    # within
    NUM_CHAINS_PARTICIPANTS = 2
    TARGET_NUM_PARTICIPANTS = 50
    repeat_same_chain = True
else:
    INITIAL_RECRUITMENT_SIZE = 30
    MAIN_PERFORMANCE_THRESH = 0
    MAX_NUM_FAILED_TRIALS_ALLOWED = 10
    # all
    NUM_ITERATIONS = 10
    NUM_TRIALS_PARTICIPANT = 40
    NUM_TRIALS_NODE = 3
    # across
    NUM_CHAINS_EXPERIMENT = 200
    # within
    NUM_CHAINS_PARTICIPANTS = 4
    TARGET_NUM_PARTICIPANTS = 50
    repeat_same_chain = False

if DESIGN == "within":
    DESIGN_PARAMS = {
        "num_trials_per_participant": int(NUM_TRIALS_PARTICIPANT + 10),
        "num_trials_practice": 3,
        "num_iterations_per_chain": NUM_ITERATIONS,
        "trials_per_node": NUM_TRIALS_NODE,
        "balance_across_chains": True,
        "chain_type": "within",
        "num_chains_per_participant": NUM_CHAINS_PARTICIPANTS,
        "recruit_mode": "num_participants",
        "target_num_participants": TARGET_NUM_PARTICIPANTS,
        "num_chains_per_experiment": None,
        "repeat_same_chain": repeat_same_chain
    }
else:
    DESIGN_PARAMS = {
        "num_trials_per_participant": int(NUM_TRIALS_PARTICIPANT),
        "num_trials_practice": 2,
        "num_iterations_per_chain": NUM_ITERATIONS,
        "trials_per_node": NUM_TRIALS_NODE,
        "balance_across_chains": False,
        "chain_type": "across",
        "num_chains_per_participant": None,
        "recruit_mode": "num_trials",
        "target_num_participants": None,
        "num_chains_per_experiment": NUM_CHAINS_EXPERIMENT,
        "repeat_same_chain": repeat_same_chain
    }

########################################################################################################################
# experiment parts
########################################################################################################################


def get_from_definition(definition, key):
    try:
        return definition[key]
    except KeyError as e:
        if key == "dimensions":
            raise e
        raise KeyError(
            f"get_from_definition requires '{key}' to be specified in each Condition object."
        )


class CustomTrial(ImitationChainTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial"}

    time_estimate = TIME_ESTIMATE
    timbre = TIMBRE

    def make_definition(self, experiment, participant):
        definition = super().make_definition(experiment, participant)

        dimensions = definition["dimensions"]
        location = definition["location"]
        slider_width = PARAMS["slider_width"]
        slider_jitter = PARAMS["slider_jitter"]
        allow_slider_outside_range = PARAMS["allow_slider_outside_range"]

        if slider_jitter > slider_width / 2:
            raise ValueError(
                "'slider_jitter' must not be greater than slider_width / 2."
            )

        active_index = random.randrange(len(dimensions))

        slider_range = self.sample_slider_range(
            dimensions[active_index],
            location[active_index],
            slider_width,
            slider_jitter,
            allow_slider_outside_range,
        )

        slider_start_value = random.uniform(*slider_range)

        definition["active_index"] = active_index
        definition["slider_range"] = slider_range
        definition["slider_start_value"] = slider_start_value

        return definition

    def show_trial(self, experiment, participant):
        definition = self.definition
        logger.info("********** Trial123 definition: {} ********** ".format(self.definition))

        current_trial = self.position + 1
        if self.phase == "experiment":
            total_num_trials = DESIGN_PARAMS["num_trials_per_participant"]
        else:
            total_num_trials = DESIGN_PARAMS["num_trials_practice"]

        prompt =  Markup(
            f"""
            Listen carefully to the melody, then try to match it as closely as possible with the slider.            
            <br><br><i>Trial number {current_trial} our of {total_num_trials}.</i>
            <hr>
            """
        )

        melody_duration, singing_duration = estimate_time_per_trial(
            PITCH_DURATION,
            NUM_INT + 2,
            PARAMS["retention_interval"]
        )

        progress_bar = ProgressDisplay(
            # duration=10000,
            stages=[
                ProgressStage(
                    [0.0, melody_duration],
                    "Listen...",
                    color="red"
                ),
                ProgressStage(
                    [melody_duration, melody_duration],
                    "Get ready...",
                    color="orange",
                ),
                ProgressStage(
                    [melody_duration, 10000],
                    "Your turn!",
                    color="green",
                ),
            ],
            show_bar=False,
        )

        return psychophysics.utils.MelodySliderPage(
            label="Melody slider copy",
            starting_values=definition["location"] ,
            active_idx=definition["active_index"],
            reference_pitch=definition["reference_pitch"],
            min_value=definition["slider_range"][0],
            max_value=definition["slider_range"][1],
            reference_mode=PARAMS["pitch_reference_mode"],
            dimensions=len(definition["dimensions"]),
            text=prompt,
            timbre=self.timbre,
            default_duration=note_duration_tonejs,
            default_silence=note_silence_tonejs,
            time_estimate=self.time_estimate,
            enable_slider_after=PARAMS["retention_interval"],
            slider_start_value=definition["slider_start_value"],
            slider_reference_pitch=None,
            progress_display=progress_bar,
            minimal_interactions=PARAMS["min_slider_interactions"]
        )

    @staticmethod
    def sample_slider_range(
        dimension, target_value, slider_width, slider_jitter, allow_slider_outside_range
    ):
        scale = dimension["scale"]
        min_value = dimension["min_value"]
        max_value = dimension["max_value"]

        rescaled_slider_width = slider_width * scale
        rescaled_slider_jitter = slider_jitter * scale

        unjittered_slider_bottom = target_value - rescaled_slider_width / 2
        unjittered_slider_top = target_value + rescaled_slider_width / 2

        if allow_slider_outside_range:
            jitter_min = -rescaled_slider_jitter
            jitter_max = +rescaled_slider_jitter
        else:
            # The lowest possible jitter value happens when the slider touches the bottom of the range:
            # unjittered_slider_bottom + jitter_min = min_value
            # => jitter_min = min_value - unjittered_slider_bottom
            jitter_min = max(
                -rescaled_slider_jitter, min_value - unjittered_slider_bottom
            )

            # The highest possible jitter value happens when the slider touches the top of the range:
            # unjittered_slider_top + jitter_max = max_value
            # => jitter_max = max_value - unjittered_slider_top
            jitter_max = min(rescaled_slider_jitter, max_value - unjittered_slider_top)

        jitter = random.uniform(jitter_min, jitter_max)
        slider_bottom = unjittered_slider_bottom + jitter
        slider_top = unjittered_slider_top + jitter

        return [slider_bottom, slider_top]

    def score_answer(self, answer, definition):
        location = get_from_definition(definition, "location")
        active_index = get_from_definition(definition, "active_index")
        target_value = location[active_index]
        actual_value = float(answer)
        return abs(target_value - actual_value)

    def compute_bonus(self, score):
        max_trial_bonus = PARAMS["max_trial_bonus"]
        bonus_threshold_semitones = PARAMS["bonus_threshold_semitones"]
        return round(max(0.0, max_trial_bonus * (1 - score / bonus_threshold_semitones)), ndigits=2)

    def show_feedback(self, experiment, participant):
        bonus_threshold_semitones = PARAMS["bonus_threshold_semitones"]
        if self.score < 0.25:
            feedback = f"Excellent job - you win the maximum bonus ${self.bonus:.2f}!"
        elif self.score < bonus_threshold_semitones:
            feedback = f"Good job - you win ${self.bonus:.2f}!"
        else:
            feedback = f"Not so good this time..."

        return InfoPage(feedback, time_estimate=1)


class CustomNetwork(ImitationChainNetwork):
    __mapper_args__ = {"polymorphic_identity": "custom_network"}


class CustomNode(ImitationChainNode):
    __mapper_args__ = {"polymorphic_identity": "custom_node"}

    def summarize_trials(self, trials: list, experiment, participant):

        # import pydevd_pycharm
        # pydevd_pycharm.settrace('localhost', port=12345, stdoutToServer=True, stderrToServer=True)

        answers = [trial.answer for trial in trials]
        # mean_answer = np.mean(answers)
        median_answer = np.median(answers)

        reference_pitch = melodies.sample_reference_pitch(
            roving_mean,
            roving_width,
        )

        return dict(
            register="default",  # all melodies are generated in the high register
            answers=answers,
            location=[median_answer],
            trial_type="node_trial",
            reference_pitch=reference_pitch,
            dimensions=PARAMS["dimensions"],
        )


class CustomSource(ImitationChainSource):
    __mapper_args__ = {"polymorphic_identity": "custom_source"}

    def generate_seed(self, network, experiment, participant):

        reference_pitch = melodies.sample_reference_pitch(
            roving_mean,
            roving_width,
        )

        # old pilots
        # max_interval2reference = MAX_INTERVAL2REFERENCE
        # num_notes = (NUM_INT + 1)

        # target_pitches = melodies.sample_absolute_pitches(
        #     reference_pitch=reference_pitch,
        #     max_interval2reference=max_interval2reference,
        #     num_pitches=num_notes
        # )
        # target_intervals = melodies.convert_absolute_pitches_to_interval_sequence(target_pitches, "previous_note")

        target_intervals = melodies.sample_interval_sequence(
                n_int=NUM_INT,
                max_interval_size=MAX_INT_SIZE,
                max_melody_pitch_range=999,
                discrete=False,
                reference_mode=REFERENCE_MODE
            )

        return dict(
            register="default",  # all melodies are generated in the high register
            location=target_intervals,
            trial_type="source_trial",
            reference_pitch=reference_pitch,
            dimensions=PARAMS["dimensions"],
        )


class ImitationChainTrialMakerMain(ImitationChainTrialMaker):
    give_end_feedback_passed = False
    performance_check_type = "performance"
    performance_check_threshold = MAIN_PERFORMANCE_THRESH

    def finalize_trial(self, answer, trial, experiment, participant):
        # failing criteria
        if abs(answer) > MAX_INT_SIZE:
            trial.fail()

        super().finalize_trial(answer, trial, experiment, participant)
        self.add_to_participated_networks(participant, trial.network_id)

    def find_networks(self, participant, experiment, ignore_async_processes=False):
        # get available networks
        old_networks = super().find_networks(participant, experiment, ignore_async_processes)
        new_networks = []
        for network in old_networks:
            # get available infor per network
            infos = Info.query.filter_by(network_id=network.id).all()
            max_degree = max([info.degree for info in infos], default=0)
            # get N failed infor in the most recent degree
            num_failed_infos = sum([info.failed for info in infos if
                                    info.degree == max_degree])

            if num_failed_infos < MAX_NUM_FAILED_TRIALS_ALLOWED:
                new_networks.append(network)
            else:
                logger.info("****** Network {} failed ******".format(network.id))
                logger.info("****** Too many failed infos: {} ******".format(num_failed_infos))

        return new_networks


main_trialmaker = ImitationChainTrialMakerMain(
        id_="slider_imitation_trialmaker",
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="experiment",
        chain_type=DESIGN_PARAMS["chain_type"],
        num_trials_per_participant=DESIGN_PARAMS["num_trials_per_participant"],
        num_iterations_per_chain=DESIGN_PARAMS["num_iterations_per_chain"],
        num_chains_per_participant=DESIGN_PARAMS["num_chains_per_participant"],  # only relevant if chain_type="within"
        num_chains_per_experiment=DESIGN_PARAMS["num_chains_per_experiment"],  # only relevant if chain_type="across"
        trials_per_node=DESIGN_PARAMS["trials_per_node"],
        balance_across_chains=DESIGN_PARAMS["balance_across_chains"],
        check_performance_at_end=True,
        check_performance_every_trial=False,
        propagate_failure=False,
        recruit_mode=DESIGN_PARAMS["recruit_mode"],
        target_num_participants=DESIGN_PARAMS["target_num_participants"],
        allow_revisiting_networks_in_across_chains=DESIGN_PARAMS["repeat_same_chain"],
    )


########################################################################################################################
# instructions
########################################################################################################################
headphones_warning = InfoPage(
    Markup(
        """
        <h3>Attention</h3>
        <hr>
        <b><b>You must use headphones or earplugs</b></b>. 
        <br><br>
        If you do not, the experiment will terminate early.
        <hr>
        <img style="width:75%" src="/static/images/headphones.png"  alt="headphones text-align: center">
        """
    ),
    time_estimate=1
)


instructions_main = join(
    InfoPage(
        Markup(
            f"""
            <h3>Main Experiment</h3>
            <hr>
            You will take a total of {NUM_TRIALS_PARTICIPANT} trials. <br><br>
            In each trial, you will hear a melody and your goal is to copy that melody with your slider.
            <hr>
            """
        ),
        time_estimate=1
    ),
    InfoPage(
        Markup(
            f"""
            <h3>Attention</h3>
            <hr>
            You will be awarded performance bonuses depending on how well you answer each question.
            You will only hear the reference melody once, so listen carefully to do as well as possible!
            <hr>
            """
            ),
            time_estimate=1
        ),
)

welcome = InfoPage(
    Markup(
        """
        <h3>Welcome</h3>
        <hr>
        In this experiment, you will hear melodies and be asked to imitate them with a slider.<br><br>
        You will be awarded performance bonuses after each response, depending on how well you answer each question.
        <hr>
        """
    ),
    time_estimate=1
)


########################################################################################################################
# timeline
########################################################################################################################
class Exp(psynet.experiment.Experiment):
    def __init__(self, session=None):
        super().__init__(session)
        self.initial_recruitment_size = INITIAL_RECRUITMENT_SIZE

    if DEBUG:
        timeline = Timeline(
            NoConsent(),
            welcome,
            instructions_main,
            main_trialmaker,
            SuccessfulEndPage(),
        )
    else:
        timeline = Timeline(
            MainConsent(),
            CodeBlock(lambda experiment: experiment.var.set("show_progress_bar", False)),
            welcome,
            headphones_warning,
            HeadphoneTest(),
            InfoPage("You passed the headphone screening task! Congratulations.", time_estimate=1),
            ToneJSVolumeTest(timbre=TIMBRE),
            psychophysics.SliderCopyPitchIntervalTraining(
                params=PARAMS,
                conditions=CONDITIONS,
                timbre_=TIMBRE,
                default_duration=note_duration_tonejs,
                default_silence=note_silence_tonejs,
                time_estimate=TIME_ESTIMATE,
                num_practice_trials=DESIGN_PARAMS["num_trials_practice"]
            ),
            InfoPage(
                """
                That's the end of the training.
                When you're ready, press 'Next' to continue to the main experiment.
                """,
                time_estimate=1,
            ),
            instructions_main,
            main_trialmaker,
            InfoPage(Markup("Congratulations, you finished the main singing task"), time_estimate=1),
            BasicDemography(),
            GMSI(label="GMSI_MT", subscales=["Musical Training"]),
            GMSI(label="GMSI_SA", subscales=["Singing Abilities"]),
            Feedback(),
            SuccessfulEndPage(),
    )

    @property
    def ad_payment_information(self):
        return f"""
            Payment in this HIT depends on your performance: after each trial, we will assess the accuracy of your
            responses and provide a bonus accordingly. 
            <br>
            In some cases, the experiment may finish early: this is not an error, and there is no need to write to us.
            <br>
            In this case you will be paid in proportion to the amount of the experiment that you completed.
            """
