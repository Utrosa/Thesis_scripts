from flask import Markup
import jsonpickle

from psynet.trial.dense import (
    SliderCopyTrial,
    DenseTrialMaker,
)

from psynet.js_synth import JSSynth, Note, Rest
from psynet.modular_page import ModularPage, PushButtonControl
from psynet.page import InfoPage
from psynet.timeline import ProgressDisplay, ProgressStage, Event, Module

import random

from flask import Markup

from . import utils

from .utils import get_duration


def combine_pitch_sequences(pitch_sequences, note_duration, note_silence, inter_stimulus_interval):
    n_sequences = len(pitch_sequences)
    notes = []

    for i_seq, pitch_sequence in enumerate(pitch_sequences):
        n_pitches = len(pitch_sequence)
        for i_pitch, pitch in enumerate(pitch_sequence):
            _note_duration = note_duration
            _note_silence = note_silence
            is_last_pitch = (i_pitch == n_pitches - 1)
            is_last_sequence = (i_seq == n_sequences - 1)
            if is_last_pitch and not is_last_sequence:
                _note_silence += inter_stimulus_interval
            note = Note(pitch, duration=_note_duration, silence=_note_silence)
            notes.append(note)

    return notes


class PitchIntervalTrial():
    # Timbre needs to be set manually
    timbre = None

    def sample_location(self, dimensions, definition):
        return utils.sample_interval_sequence(
            n_int=len(dimensions),
            max_interval_size=definition["max_interval_size"],
            max_melody_pitch_range=definition["max_melody_pitch_range"],
            discrete=False,
            reference_mode=definition["pitch_reference_mode"],
        )

    def within_bounds(self, location, dimensions, definition):
        return utils.is_valid_interval_sequence(
            intervals=location,
            n_int=len(location),
            max_interval_size=definition["max_interval_size"],
            max_melody_pitch_range=definition["max_melody_pitch_range"],
            reference_mode=definition["pitch_reference_mode"],
        )

    def sample_reference_pitch(self, definition):
        return utils.sample_reference_pitch(
            definition["roving_mean"],
            definition["roving_width"],
        )

    def sample_reference_pitches(self, definition, n):
        transpose_within_trial = self.get_from_definition(definition, "transpose_within_trial")
        if transpose_within_trial:
            transpose_within_trial_min_step_size = self.get_from_definition(
                definition,
                "transpose_within_trial_min_step_size"
            )
            transpose_within_trial_max_step_size = self.get_from_definition(
                definition,
                "transpose_within_trial_max_step_size"
            )
            step_size = random.uniform(
                transpose_within_trial_min_step_size,
                transpose_within_trial_max_step_size
            )
            step_direction = random.sample(population=[-1, 1], k=1)[0]
            step = step_size * step_direction

            initial_reference_pitch = self.sample_reference_pitch(definition)
            return [initial_reference_pitch + i * step for i in range(n)]
        else:
            _reference_pitch = self.sample_reference_pitch(definition)
            return [_reference_pitch for _ in range(n)]

    @property
    def melody_duration(self):
        n_intervals = self.n_dimensions
        n_pitches = 1 + n_intervals
        return n_pitches * (self.definition["note_duration"] + self.definition["note_silence"])

    def is_valid_location_pair(self, definition, original, altered):
        allow_contour_change = self.get_from_definition(definition, "allow_contour_change")
        if allow_contour_change:
            return True
        else:
            original_contour = [interval > 0 for interval in original]
            altered_contour = [interval > 0 for interval in altered]
            return original_contour == altered_contour


class SliderCopyPitchIntervalTrial(PitchIntervalTrial, SliderCopyTrial):
    time_estimate = None

    def make_definition(self, experiment, participant):
        definition = super().make_definition(experiment, participant)
        definition["reference_pitches"] = self.sample_reference_pitches(definition, n=2)
        return definition

    def show_trial(self, experiment, participant):
        definition = self.definition

        intervals = definition["location"]
        prompt_reference_pitch, slider_reference_pitch = definition["reference_pitches"]

        assert self.time_estimate is not None

        return utils.MelodySliderPage(
            label="Melody slider copy",
            starting_values=intervals,
            active_idx=definition["active_index"],
            reference_pitch=prompt_reference_pitch,
            min_value=definition["slider_range"][0],
            max_value=definition["slider_range"][1],
            reference_mode=definition["pitch_reference_mode"],
            dimensions=len(definition["location"]),
            text="Listen carefully to the melody, then try to match it as closely as possible with the slider.",
            timbre=self.timbre,
            default_duration=definition["note_duration"],
            default_silence=definition["note_silence"],
            time_estimate=self.time_estimate,
            enable_slider_after=definition["retention_interval"],
            slider_start_value=definition["slider_start_value"],
            slider_reference_pitch=slider_reference_pitch,
            progress_display=self.progress_display,
        )

    @property
    def progress_display(self):
        definition = self.definition
        melody_duration = self.melody_duration

        return ProgressDisplay(
            # duration=10000,
            stages=[
                ProgressStage(
                    [0.0, melody_duration],
                    "Listen...",
                    color="red"
                ),
                ProgressStage(
                    [melody_duration, melody_duration + definition["retention_interval"]],
                    "Get ready...",
                    color="orange",
                ),
                ProgressStage(
                    [melody_duration + definition["retention_interval"], 10000],
                    "Your turn!",
                    color="green",
                ),
            ],
            show_bar=False,
        )

    def compute_bonus(self, score):
        definition = self.definition
        max_trial_bonus = self.get_from_definition(definition, "max_trial_bonus")
        bonus_threshold_semitones = self.get_from_definition(definition, "bonus_threshold_semitones")
        return round(max(0.0, max_trial_bonus * (1 - score / bonus_threshold_semitones)), ndigits=2)

    def show_feedback(self, experiment, participant):
        bonus_threshold_semitones = self.get_from_definition(self.definition, "bonus_threshold_semitones")
        if self.score < 0.25:
            feedback = f"Excellent job - you win the maximum bonus ${self.bonus:.2f}!"
        elif self.score < bonus_threshold_semitones:
            feedback = f"Good job - you win ${self.bonus:.2f}!"
        else:
            feedback = f"Not so good this time..."

        return InfoPage(feedback, time_estimate=3)


def progress_display_for_pitch_sequences(
        pitch_sequences,
        note_duration,
        note_silence,
        inter_stimulus_interval,
        messages=None,
    ):
    n_pitch_sequences = len(pitch_sequences)

    if messages is None:
        messages = [f"Melody {i + 1}..." for i in range(n_pitch_sequences)]

    stages = []
    for i, pitch_sequence in enumerate(pitch_sequences):
        _n_pitches = len(pitch_sequence)
        _duration = _n_pitches * (note_duration + note_silence)
        stages.append(ProgressStage(_duration, messages[i]))
        if i < n_pitch_sequences - 1:
            stages.append(ProgressStage(inter_stimulus_interval, ""))
    return ProgressDisplay(stages, show_bar=False, start="promptStart")


class SliderCopyPitchIntervalTraining(Module):
    def __init__(
            self,
            params,
            conditions,
            timbre_,
            default_duration,
            default_silence,
            time_estimate,
            num_practice_trials,
            id_="slider_copy_pitch_interval_training"
    ):
        # n_intervals = set([len(condition.definition["dimensions"]) for condition in conditions])

        elts = list()

        elts.append(
            InfoPage(
                """
                In this part of the experiment you will be presented with a slider.
                When you move the slider, a melody will be played.
                Different slider positions will produce different melodies.
                """,
                time_estimate=5
            ),
        )

        elts.append(
            utils.MelodySliderPage(
                label="Melody slider example",
                starting_values=[3.5],
                active_idx=0,
                reference_pitch=60,
                min_value=-7,
                max_value=7,
                reference_mode="first_note",
                dimensions=1,
                text="Here's an example slider.",
                timbre=timbre_,
                default_duration=params["note_duration"],
                default_silence=params["note_silence"],
                time_estimate=time_estimate,
            ),
        )

        elts.append(
            InfoPage(
                """
                At the beginning of each trial, you will be played a particular melody.
                Your task will then be to copy that melody with your slider.
                """,
                time_estimate=3,
            ),
        )

        elts.append(
            InfoPage(
                """
                You will be awarded performance bonuses depending on how well you answer each question.
                You will only hear the reference melody once, so listen carefully to do as well as possible!
                """,
                time_estimate=5,
            )
        )

        elts.append(
            InfoPage(
                f"""
                We'll start off with {num_practice_trials} practice questions so you can see how the experiment works.
                """,
                time_estimate=3,
            )
        )

        class SliderCopyPitchIntervalPracticeTrial(SliderCopyPitchIntervalTrial):
            __mapper_args__ = {"polymorphic_identity": id_ + "_trial"}

            timbre = timbre_
            time_estimate = 3

        elts.append(
            DenseTrialMaker(
                id_=id_ + "_trials",
                trial_class=SliderCopyPitchIntervalPracticeTrial,
                conditions=conditions,
                max_trials_per_block=num_practice_trials,
            )
        )

        super().__init__(id_, *elts)


def play_pitch_sequences(pitch_sequences, text, params, timbre, delay=0.0, messages=None):
    note_sequence = combine_pitch_sequences(
        pitch_sequences,
        note_duration=params["note_duration"],
        note_silence=params["note_silence"],
        inter_stimulus_interval=params["inter_stimulus_interval"],
    )
    time_estimate = sum(note["duration"] + note["silence"] for note in note_sequence) + delay

    return ModularPage(
        "play_pitch_sequence",
        JSSynth(
            text,
            sequence=note_sequence,
            timbre=timbre,
        ),
        events=dict(
            promptStart=Event(is_triggered_by="trialStart", delay=delay),
            responseEnable=Event(is_triggered_by="promptEnd"),
            submitEnable=Event(is_triggered_by="promptEnd"),
        ),
        time_estimate=time_estimate,
        progress_display=progress_display_for_pitch_sequences(
            pitch_sequences,
            note_duration=params["note_duration"],
            note_silence=params["note_silence"],
            inter_stimulus_interval=params["inter_stimulus_interval"],
            messages=messages,
        ),
    )
