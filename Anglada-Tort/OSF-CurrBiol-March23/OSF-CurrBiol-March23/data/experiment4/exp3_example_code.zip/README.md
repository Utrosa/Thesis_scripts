# iterated learning with a slider
This repository contains all the experimental data and code used for experiments using iterated-singing with 10 iterations and pitch representation

## List of Pilots (pre bug)

1. Study 1: `data-demo-slider1` - pilot experiment

2. Study 2: `data-btw-2t-slide1a` - batch 1 using slider (200 across chains) with x3 aggregation:
    - pitch mode
    - mac_int2refernece = 7.5
    - max_int_slider = 7.5
    - slider_width = 5.5
    - allow_values_outside_range = False
    - BUG: pitches in the seed were outside the slider range, and people could not match them (25% chains)

3. Study 3: `data-btw-2t-slide1b` - batch 2 (same as above)
    - BUG: pitches in the seed were outside the slider range, and people could not match them (25% chains)

4. Study 4: `data-btw-2t-slide2.15` - same params as above but using max_int_slider = 15
    - BUG: pitches in the seed were outside the slider range, and people could not match them (25% chains)

## List of Pilots (post bug)

5. Study 5: `data-btw-2t-slider1` - batch 1 slider (200 across chains) with NO aggregation:
    - previous_note representation + BUG: fixed
    - max_int_slider = 7.5
    - slider_width = 5.5
    - allow_values_outside_range = False

5. Study 5: `data-btw-2t-slider2` - batch 1 slider (200 across chains) with x3 aggregation:
    - previous_note representation + BUG: fixed
    - max_int_slider = 15
    - slider_width = 7.5
    - allow_values_outside_range = True + Failining criteria


5. Study 5: `data-btw-2t-slider3` - batch 1 slider (200 across chains) with x3 aggregation:
    - previous_note representation + BUG: fixed
    - max_int_slider = 10
    - slider_width = 5
    - allow_values_outside_range = True + Failining criteria