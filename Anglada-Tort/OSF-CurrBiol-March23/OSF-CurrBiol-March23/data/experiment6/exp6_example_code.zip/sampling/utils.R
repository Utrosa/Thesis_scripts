# functions

# sampling modes
sample_interval = function(max_interval_size, num_int){
  return(runif(num_int, -max_interval_size, max_interval_size))
}


convert_intervals_to_pitches = function(reference_pitch, interval, first_note = TRUE){
  if (first_note){
    first_note = reference_pitch
    other_notes = to_vec(for(i in interval) ((i + reference_pitch)))
    pitches = c(first_note, other_notes)
  } else {
    pitches = c(reference_pitch)
    for (i in interval){
      last_pitch = tail(pitches, n=1)
      new_pitch = last_pitch + i
      pitches = c(pitches, new_pitch)
    }
  }
  return(pitches)
}


sample_stimuli_first_interval_mode = function(
    roving_mean, 
    roving_width, 
    max_interval_size,
    num_int,
    iterations
){
  require(comprehenr)
  
  df <- data.frame(matrix(NA, nrow = iterations, ncol = (num_int + 3)))
  
  for(i in 1:iterations){
    interval <- sample_interval(max_interval_size, num_int)
    reference_pitch = sample_reference_pitch(roving_mean, roving_width)
    pitches = convert_intervals_to_pitches(reference_pitch, interval)
    df[i,] <- c(interval, reference_pitch, pitches)
  }
  
  colnames(df) <- c("interval", "reference_pitch", "pitch1", "pitch2")
  
  return(as_tibble(df))
}


sample_reference_pitch = function(roving_mean, roving_width){
  reference_pitch <- runif(1, (roving_mean-roving_width), (roving_mean+roving_width))
  return(reference_pitch) 
}


sample_pitches = function(
    roving_mean, roving_width, max_melody_range, num_int, round_pitches = FALSE
){
  reference_pitch = sample_reference_pitch(roving_mean, roving_width)
  random_numbers = c(runif((num_int + 1), -max_melody_range, max_melody_range))
  if (round_pitches) {
    pitches = round(reference_pitch + random_numbers)
    
  } else {
    pitches = reference_pitch + random_numbers
  }
  
  out = c(reference_pitch, pitches)
  
  return(out) 
}


sample_pitches_fixed.base.tone = function(reference_pitch, max_melody_range, num_int){
  random_numbers = c(runif((num_int), -max_melody_range, max_melody_range))
  
  pitches = c()
  for(n in 1:num_int){
    if(num_int==1){
      pitches = c(reference_pitch, (reference_pitch + random_numbers))
    }else{
      print("NOT IMPLEMENTED")
    }
  }
  
  return(pitches) 
}

sample_stimuli_pitch_mode = function(
    roving_mean, 
    roving_width, 
    max_pitch_height,
    num_int,
    iterations,
    round_pitches
){
  
  df <- data.frame(matrix(NA, nrow = iterations, ncol = (num_int + 2)))
  
  for(i in 1:iterations){
    df[i,] <- sample_pitches(
      roving_mean, roving_width, max_pitch_height, num_int, 
      round_pitches = round_pitches)
  }
  colnames(df) <- c("reference_pitch", "pitch1", "pitch2")
  
  return(as_tibble(df))
}


sample_stimuli_pitch_mode_blocking = function(
    roving_mean, 
    roving_width, 
    max_pitch_height,
    num_int,
    iterations,
    n_blocks,
    round_pitches
){
  
  df1 = c()
  df2 = c()
  
  for(b in 1:n_blocks){
    reference_pitch = sample_reference_pitch(roving_mean, roving_width)
    for(i in 1:iterations){
      p = sample_pitches_fixed.base.tone(reference_pitch, max_pitch_height, 1)
      df1[[i]] = tibble(
        pitch1 = p[[1]],
        pitch2 = p[[2]],
        block_n = b,
        reference_pitch = reference_pitch,
        iteration = i
      )
      print(paste0("Block ", i, " out of ", n_blocks))
    }
    df2[[b]] = do.call(rbind, df1)
    
  }
  out = do.call(rbind, df2)
  return(out)
}


# visualize distribution
visualize_distributions = function(data){
  # pitches
  data_sampled_pitch =
    data %>%
    pivot_longer(cols = starts_with("pitch"), names_to = "condition", values_to = "pitch")
  
  plot_pitch = data_sampled_pitch  %>%
    ggplot(aes(x = pitch)) +
    geom_histogram(colour="black", fill="white", binwidth = BW) +
    scale_x_continuous(breaks=seq(40, 70, 5), limits = c(40,70))  +
    xlab("Pitch") + ylab("Counts") +
    theme_bw() +
    theme(axis.text.x = element_text(size=12), 
          axis.text.y=element_text(size=12)
    ) +
    ggtitle("Distribution pitches")
  
  # intervals
  data_sampled_interval =
    data %>%
    mutate(interval = (pitch2 - pitch1))
  
  plot_interval = data_sampled_interval  %>%
    ggplot(aes(x = interval)) +
    geom_histogram(colour="black", fill="white", binwidth = BW) +
    scale_x_continuous(breaks=seq(-15,15, 5), limits = c(-15,15))  +
    xlab("Interval") + ylab("Counts") +
    theme_bw() +
    theme(axis.text.x = element_text(size=12), 
          axis.text.y=element_text(size=12)
    ) +
    ggtitle("Distribution intervals")
  
  plots = plot_grid(plot_pitch, plot_interval, ncol=1)
  return(plots)
} 


# plots
make_histogram = function(data, bw, is_density = TRUE){
  plot = data %>% ggplot(aes(interval))
  
  if (is_density){
    plot = plot  +     
      geom_histogram(aes(y=..density..), colour="black", fill="white", binwidth = bw) +
      geom_density(alpha=.2, fill="#FF6666") 
  } else  {
    plot = plot +
      geom_histogram(colour="black", fill="white", binwidth = bw)
  }
  plot = plot + theme_bw() + facet_wrap(~condition, scales = "free")
  plot
}


count_contour_class = function(data, min_int_tresh, max_int_tresh){
  data_sum = data %>%
    select(interval1, interval2) %>%
    mutate(contour_int1 = ifelse(interval1 < min_int_tresh, "down",
                                 ifelse(interval1 > max_int_tresh, "up", "same"))) %>%
    mutate(contour_int2 = ifelse(interval2 < min_int_tresh, "down",
                                 ifelse(interval2 > max_int_tresh, "up", "same"))) %>%
    mutate(contour_class = ifelse(contour_int1 == "up" & contour_int2 == "up", "up-up", 
                                  ifelse(contour_int1 == "down" & contour_int2 == "down", "down-down",
                                         ifelse(contour_int1 == "up" & contour_int2 == "down", "arched",
                                                ifelse(contour_int1 == "down" & contour_int2 == "up", "U-arched",
                                                       "horizontal"))))) %>%
    dplyr::group_by(contour_class) %>%
    dplyr::mutate(n = n(),
                  percentage = (n/ iterations) * 100) %>%
    dplyr::summarise(percentage = mean(percentage))
  return(data_sum)
}


make_histogram2 = function(data, bw, x_lab, title, is_density = FALSE){
  plot = data %>% ggplot(aes(group_variable))
  
  if (is_density){
    plot = plot  +     
      geom_histogram(aes(y=..density..), colour="black", fill="white", binwidth = bw) +
      geom_density(alpha=.2, fill="#FF6666") 
  } else  {
    plot = plot +
      geom_histogram(colour="black", fill="white", binwidth = bw) +
      xlab(x_lab) +
      ggtitle(title)
  }
  plot = plot + theme_bw() + facet_wrap(~condition, scales = "free")
  plot
}

make_intervals = function(data_6pitches){
  data_ints = data_6pitches %>% 
    mutate(
      # first note
      int1_firstnote = p2 - p1,
      int2_firstnote = p3 - p1,
      int3_firstnote = p4 - p1,
      int4_firstnote = p5 - p1,
      int5_firstnote = p6 - p1,
      # pervious note
      int1_prenote = p2 - p1,
      int2_prenote = p3 - p2,
      int3_prenote = p4 - p3,
      int4_prenote = p5 - p4,
      int5_prenote = p6 - p5
    )
  return(data_ints)
}

count_contour_class = function(data, int1, int2, min_int_tresh, max_int_tresh, iterations){
  eint1 = enquo(int1)
  eint2 = enquo(int2)
  
  data_sum = data %>%
    select(!!eint1, !!eint2) %>%
    dplyr::mutate(contour_int1 = ifelse(!!eint1 < min_int_tresh, "down",
                                        ifelse(!!eint1 > max_int_tresh, "up", "same"))) %>%
    dplyr::mutate(contour_int2 = ifelse(!!eint2 < min_int_tresh, "down",
                                        ifelse(!!eint2 > max_int_tresh, "up", "same"))) %>%
    dplyr::mutate(contour_class = ifelse(contour_int1 == "up" & contour_int2 == "up", "up-up", 
                                         ifelse(contour_int1 == "down" & contour_int2 == "down", "down-down",
                                                ifelse(contour_int1 == "up" & contour_int2 == "down", "arched",
                                                       ifelse(contour_int1 == "down" & contour_int2 == "up", "U-arched",
                                                              "horizontal"))))) %>%
    dplyr::group_by(contour_class) %>%
    dplyr::mutate(n = n(),
                  percentage = (n/ iterations) * 100) %>%
    dplyr::summarise(percentage = mean(percentage))
  return(data_sum)
}


make_bar_plot_countors = function(data){
  plot = data %>%
    ggplot(aes(x = contour_class, y = percentage)) +
    geom_text(aes(label=percentage), position=position_dodge(width=0.9), vjust=-0.25) +
    ggtitle("Percentage of countour classes (1K seeds)") +
    geom_bar(stat="identity") + theme_minimal()
  return(plot)
}
