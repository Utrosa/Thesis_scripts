## Cross-cultural datasets
 11. India batch 1: `data-btw-3tones-in1`
     - iterated sining 2 int + within + pitch mode + 10 iterations:
     - max_abs_int_)allowed = 5.5
     - max_intercal2reference = 10
     - 8 finished participatns