roving_mean = dict(
    default=55,  # it was 55.5
    low=49,  # it was 49.5 (male)
    high=61,  # it was 61.5 (female)
)

singing_register_threshold = 55

roving_width = dict(
    default=2.5,
)


# general prams for singing experiments
singing_config = dict(
    # singing task
    reference_mode="pitch_mode",
    max_melody_pitch_range=99,  # not used
    # max_interval2reference_seed=10,  # previously we used 7.5 and 9.5
    # max_interval2reference=20,
    max_interval_size=99,  # deactivated
    discrete=False,  # True means that everything is quantized to the 12-tone scale
    # max_abs_mean_interval_error=5.5,
    # singing sing4me
    sample_rate=44100,
    peak_time_difference=70,  # Calculated with: ms_to_samples(70, fs=STANDARD_FS),
    minimum_peak_height=0.05,
    db_threshold=-22, # used to be -22
    db_end_threshold_realtive_2note_start=-10, # used to be -10
    max_vs_start_threshold_importance = 0.9,
    msec_silence=70,  # was 90 (minimal silence between segments - increase to require more time between segments
    silence_beginning_ms= 50,
    extend_pitch_threshold_semitones=2.0,
    praat_extend_proximity_threshold_ms=150.0,  # (ms) max allowed extension of onset of the sung tone based on paraat - if the onset computed from paraat is deviating more than this threshold the onset would not be extended!
    #cut_pre=110,  # time ignored at start of seg (ms)
    #cut_post=70,  # time ignored at end of seg (ms)
    cut_pre=30,  # time ignored at start of seg (ms)
    cut_post=50,  # time ignored at end of seg (ms)
#    minimal_segment_duration=35,  # minimal time in sec that segment should have (ms)
    minimal_segment_duration=70,  # minimal time in sec that segment should have (ms)
    pitch_range_allowed=[36, 75],
    # used to be [36,84] range of acceptable pitches - this is used in the detection algorithm to eliminate areas of no allowed pitch detected - Nori modified the highest pitch to 75 as  praat defualt i detecting up to 600 Hz
    singing_bandpass_range=[80, 6000],  # in Hz - we use this to bandpass filtering the audio
    #singing_bandpass_range_praat_syllable= [1200,7000], # in Hz - we use this to bandpass filtering the audio for syllable extraction
    singing_bandpass_range_praat_syllable= [300,6000], # in Hz - we use this to bandpass filtering the audio for syllable extraction ; this paramters used by Erika in her tpping experiments and found to be good.
    allowed_pitch_flactuations_witin_one_tone=6,  # in semitones - max flactuations that is conisdered OK
    percent_of_flcatuating_within_one_tone=20.0,
    # exclude tones with more than that percent if they flactuate more than allowed_pitch_flactuations_witin_one_tone
    praat_octave_jump_cost=0.55,
    # praat default is 0.35 but we suspect that this is not good enough (too many octave doubling "jumps")
    praat_high_frequncy_favoring_octave_cost=0.03,
    # control octave_cost parms parrat dedault is 0.01  see https://www.fon.hum.uva.nl/praat/manual/Sound__To_Pitch__ac____.html
    praat_silence_threshold=0.03,  # praat defaule: silence_threshold = 0.03 this
)


# Nori's replication (MATLAB)
roving_mean_matlab = dict(
    low=51.5,
    high=63.5,
)

singing_config_matlab = singing_config.copy()
singing_config_matlab["reference_mode"] = "previous_note"
singing_config_matlab["max_interval_size"] = 4.5
singing_config_matlab["max_melody_pitch_range"] = 99  # deactivate
singing_config_matlab["max_interval2reference_seed"] = 99  # deactivate
singing_config_matlab["max_interval2reference"] = 99  # deactivate
