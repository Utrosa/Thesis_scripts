## Cross-cultural datasets

#### India 
1. India batch 1: `data-wth-3tones-in1`
     - iterated sining 2 int + within + pitch mode + 10 iterations:
     - max_abs_int_allowed = 5.5
     - max_intercal2reference = 10
     - within-chains
     - 8 finished participatns
2. India batch 2: `data-wth-3tones-in2`
     - second batch india
     - 10 finished participatns
3. India batch 3: `data-wth-3tones-in3`
     - third batch india
     - 21 finished participatns
4. India batch 4: `data-wth-3tones-in4`
5. India batch 5: `data-wth-3tones-in5`
6. India batch 6: `data-wth-3tones-in6`
7. India batch 7: `data-wth-3tones-in7`

8. India across batch 1: `data-btw-3tones-b1`
     - 20 finished participatns
9. India across batch 1: `data-btw-3tones-b1b`
     - 10 new particiapnts (~ 30 finished participatns)

#### Brazil 
1. India batch 1: `data-wth-3tones-br2`
     - iterated sining 2 int + within + pitch mode + 10 iterations:
     - max_abs_int_allowed = 5.5
     - max_intercal2reference = 10
     - within-chains
     - 13 finished participatns
2. India batch 2: `data-wth-3tones-in2`
     - second batch brazil
     - 17 finished 
3. India batch 2: `data-wth-3tones-in2`
     - third batch brazil
     - ??? finished participatns