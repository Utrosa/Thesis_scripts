import random
from statistics import mean
from flask import Markup
import json
# psynet
import psynet.experiment
import psynet.media
from psynet.modular_page import AudioRecordControl, ModularPage, PushButtonControl, Prompt
from psynet.page import InfoPage, SuccessfulEndPage
from psynet.js_synth import JSSynth, Note
from psynet.prescreen import HeadphoneTest
from psynet.timeline import (
    Timeline,
    PreDeployRoutine,
    join,
    ProgressDisplay,
    ProgressStage,
    Event,
    CodeBlock,
    conditional
)
from psynet.media import prepare_s3_bucket_for_presigned_urls, make_bucket_public
from psynet.consent import MainConsent, AudiovisualConsent, OpenScienceConsent, NoConsent
from psynet.trial.audio import (
    AudioImitationChainNetwork,
    AudioImitationChainNode,
    AudioImitationChainSource,
    AudioImitationChainTrial,
    AudioImitationChainTrialMaker,
)
from psynet.utils import get_logger
from psynet.demography.gmsi import GMSI
# dallinger
from dallinger.models import Info
from dallinger.config import get_config
# sing4me
from sing4me import singing_extract as sing
from sing_experiments import melodies
from sing_experiments.resources import (
    ToneJSVolumeTest,
    SingingCalibration,
    select_timbre,
    estimate_time_per_trial,
    SingingPerformanceTest
)
from sing_experiments.params import singing_2intervals
from sing_experiments.questionnaire import BasicDemography, Feedback


########################################################################################################################
# Global parameters
########################################################################################################################
DEBUG = False
DESIGN = "within"  # within vs across
IS_MATLAB_MATCH = False
UNCONSTRAINED_NUM_NOTES = False  # if true, paradigm allows for varying number of notes
NUM_NOTES = 3
SYLLABLE = 'TA'

BUCKET_NAME = "iterated-singing"
logger = get_logger()


# singing
config = singing_2intervals  # params singing extraction (from sing4me)
roving_width = 2.5

if IS_MATLAB_MATCH:
    REFERENCE_MODE = "previous_note"  # pitch_mode vs previous_note vs first_note
    roving_mean = dict(
        low=51.5,
        high=63.5
        )
else:
    REFERENCE_MODE = "pitch_mode"  # pitch_mode vs previous_note vs first_note
    roving_mean = dict(
        default=55,  # it was 55.5
        low=49,  # it was 49.5 (male)
        high=61  # it was 61.5 (female)
        )

MAX_INT_SIZE = 999  # deactivated
MAX_MELODY_PITCH_RANGE = 999  # deactivated


# select timbre: piano, complex_short_ISI_long, complex_long_ISI_long, complex_short_ISI_short, complex_mid_ISI_long
note_duration_tonejs, note_silence_tonejs, TIMBRE = select_timbre("complex_mid_ISI_long")
PITCH_DURATION = note_duration_tonejs + note_silence_tonejs

# conditional parameters
if UNCONSTRAINED_NUM_NOTES:
    MIN_NUM_NOTES = 4
    MAX_NUM_NOTES = 12
    NUM_NOTE_OPTIONS = list(range(MIN_NUM_NOTES, (MAX_NUM_NOTES + 1)))
    NUM_REPEATED_NOTES_OPTIONS = 8
    NUM_CHAINS = len(NUM_NOTE_OPTIONS) * NUM_REPEATED_NOTES_OPTIONS
    TIME_AFTER_SINGING = 3
else:
    NUM_INT = (NUM_NOTES - 1)
    TIME_AFTER_SINGING = 1
    if NUM_INT <= 2:
        TIME_ESTIMATE_TRIAL = 15
        MAX_ABS_INT_ERROR_ALLOWED = 5.5
        MAX_INTERVAL2REFERENCE = 10  # 10 in seed, 20 in failing criteria
        NUM_CHAINS_EXPERIMENT = 200
        NUM_TRIALS_PARTICIPANT = 40
    else:
        TIME_ESTIMATE_TRIAL = 22
        MAX_ABS_INT_ERROR_ALLOWED = 11
        MAX_INTERVAL2REFERENCE = 8.5
        NUM_CHAINS_EXPERIMENT = 120
        NUM_TRIALS_PARTICIPANT = 30

if DEBUG:
    INITIAL_RECRUITMENT_SIZE = 10
    num_iterations_per_chain = 5
    num_chains_per_participant = 5
    num_trials_per_participant_block1 = 50
    num_trials_per_participant_block2 = 0
    MAX_NUM_FAILED_TRIALS_ALLOWED = 2
    TARGET_NUM_PARTICIPANTS = 30
    NUM_CHAINS_EXPERIMENT = 5
    repeat_same_chain = True
else:
    INITIAL_RECRUITMENT_SIZE = 30
    num_iterations_per_chain = 10
    num_chains_per_participant = 4   # only active in within
    num_trials_per_participant_block1 = NUM_TRIALS_PARTICIPANT
    num_trials_per_participant_block2 = 0
    MAX_NUM_FAILED_TRIALS_ALLOWED = 5
    TARGET_NUM_PARTICIPANTS = 50  # only active in within
    NUM_CHAINS_EXPERIMENT = NUM_CHAINS_EXPERIMENT
    repeat_same_chain = False

if DESIGN == "within":
    DESIGN_PARAMS = {
        "num_trials_per_participant_block1": (int(num_trials_per_participant_block1) + 10),
        "num_trials_per_participant_block2": int(num_trials_per_participant_block2),
        "num_trials_practice_test": 3,
        "num_trials_practice_feedback": 4,
        "num_iterations_per_chain": num_iterations_per_chain,
        "trials_per_node": 1,
        "balance_across_chains": True,
        "performance_threshold_block1": 0.65,
        "chain_type": "within",
        "num_chains_per_participant": num_chains_per_participant,
        "recruit_mode": "num_participants",
        "target_num_participants": TARGET_NUM_PARTICIPANTS,
        "num_chains_per_exp_block1": None,
        "num_chains_per_exp_block2": None,
        "repeat_same_chain": repeat_same_chain
    }
else:
    DESIGN_PARAMS = {
        "num_trials_per_participant_block1": int(num_trials_per_participant_block1),
        "num_trials_per_participant_block2": int(num_trials_per_participant_block2),
        "num_trials_practice_test": 3,
        "num_trials_practice_feedback": 4,
        "num_iterations_per_chain": num_iterations_per_chain,
        "trials_per_node": 1,
        "balance_across_chains": False,
        "performance_threshold_block1": 0.65,
        "chain_type": "across",
        "num_chains_per_participant": None,
        "recruit_mode": "num_trials",
        "target_num_participants": None,
        "num_chains_per_exp_block1": NUM_CHAINS_EXPERIMENT,
        "num_chains_per_exp_block2": 0,
        "repeat_same_chain": repeat_same_chain
    }


########################################################################################################################
# Experiment parts
########################################################################################################################
def create_singing_trial(show_current_trial, target_pitches, time_estimate, melody_duration, singing_duration):
    singing_page = ModularPage(
        "sing_melody",
        JSSynth(
            Markup(
                f"""
                <h3>Sing back the melody</h3>
                <hr>
                <b><b>This melody has {NUM_NOTES} notes</b></b>: Sing each note clearly using the syllable '{SYLLABLE}'.
                <br><i>Leave silent gaps between notes.</i>
                <br><br>
                {show_current_trial}
                <hr>
                """
            ),
            [Note(pitch) for pitch in target_pitches],
            timbre=TIMBRE,
            default_duration=note_duration_tonejs,
            default_silence=note_silence_tonejs,
        ),
        control=AudioRecordControl(
            duration=singing_duration,
            s3_bucket=BUCKET_NAME,
            public_read=True,
            show_meter=True,
            controls=False,
            auto_advance=False,
        ),
        events={
            "promptStart": Event(is_triggered_by="trialStart"),
            "recordStart": Event(is_triggered_by="promptEnd", delay=0.25),
        },
        progress_display=ProgressDisplay(
            stages=[
                ProgressStage(melody_duration, "Listen to the melody...", "orange"),
                ProgressStage(singing_duration, "Recording...SING THE MELODY!", "red"),
                ProgressStage(0.5, "Done!", "green", persistent=True),
            ],
        ),
        time_estimate=time_estimate,
    )
    return singing_page


# class RepeatRecording(ModularPage):
#     def __init__(
#             self,
#             label: str,
#             time_estimate=3,
#     ):
#         super().__init__(
#             label,
#             "Do you want to repeat your recording?",
#             control=PushButtonControl(
#                 ["Yes", "No"]
#             ),
#             time_estimate=time_estimate,
#             save_answer="repeat_recording"
#         )


class CustomTrial(AudioImitationChainTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial"}

    accumulate_answers = False
    time_estimate = TIME_ESTIMATE_TRIAL

    def show_trial(self, experiment, participant):
        logger.info("********** Register of participant: {0} **********".format(participant.var.register))
        logger.info("********** Trial123 definition: {} ********** ".format(self.definition))

        # convert to right register
        if self.participant.var.register == "high":
            target_pitches = self.definition["target_pitches"]
        else:
            target_pitches = [(i - 12) for i in self.definition["target_pitches"]]

        melody_duration, singing_duration = estimate_time_per_trial(
            PITCH_DURATION,
            len(target_pitches) + 1,
            TIME_AFTER_SINGING
        )

        current_trial = self.position + 1
        if self.phase == "practice_feedback":
            total_num_trials = DESIGN_PARAMS["num_trials_practice_feedback"]
        elif self.phase == "practice_test":
            total_num_trials = DESIGN_PARAMS["num_trials_practice_test"]
        elif self.phase == "experiment_block2":
            total_num_trials = DESIGN_PARAMS["num_trials_per_participant_block2"]
        else:
            total_num_trials = DESIGN_PARAMS["num_trials_per_participant_block1"]
        show_current_trial = f'<br><br>Trial number {current_trial} out of {total_num_trials} possible maximum trials.'

        pages = create_singing_trial(
            show_current_trial,
            target_pitches,
            self.time_estimate,
            melody_duration,
            singing_duration
        )

        return pages

    def analyze_recording(self, audio_file: str, output_plot: str):
        # import rpdb
        # rpdb.set_trace()

        # save_plot = True if self.phase.startswith("experiment") else False
        save_plot = True

        # convert to right register
        if self.participant.var.register == "high":
            target_pitches = self.definition["target_pitches"]
            reference_pitch = self.definition["reference_pitch"]
        else:
            target_pitches = [(i - 12) for i in self.definition["target_pitches"]]
            reference_pitch = self.definition["reference_pitch"] - 12

        raw = sing.analyze(
            audio_file,
            config,
            target_pitches=target_pitches,
            plot_options=sing.PlotOptions(
                save=save_plot, path=output_plot, format="png"
            ),
        )
        raw = [
            {key: melodies.as_native_type(value) for key, value in x.items()} for x in raw
        ]
        sung_pitches = [x["median_f0"] for x in raw]
        sung_intervals = melodies.convert_absolute_pitches_to_interval_sequence(
            sung_pitches,
            "previous_note"
        )
        target_intervals = melodies.convert_absolute_pitches_to_interval_sequence(
            target_pitches,
            "previous_note"
        )
        sung_intervals2reference = melodies.convert_absolute_pitches_to_intervals2reference(
            sung_pitches,
            reference_pitch
        )
        stats = sing.compute_stats(
            sung_pitches,
            target_pitches,
            sung_intervals,
            target_intervals
        )

        if UNCONSTRAINED_NUM_NOTES:
            if len(target_pitches) in range(4, 6):
                MAX_NUM_DIFF_PITCHES_ALLOWED = 3
            elif len(target_pitches) in range(6, 9):
                MAX_NUM_DIFF_PITCHES_ALLOWED = 4
            elif len(target_pitches) in range(9, 15):
                MAX_NUM_DIFF_PITCHES_ALLOWED = 5
            else:
                MAX_NUM_DIFF_PITCHES_ALLOWED = 0

            is_failed = melodies.failing_criteria_unconstrained_notes(stats, MAX_NUM_DIFF_PITCHES_ALLOWED)
        else:
            MAX_NUM_DIFF_PITCHES_ALLOWED = 0
            is_failed = melodies.failing_criteria(
                sung_intervals,
                sung_pitches,
                reference_pitch,
                NUM_INT,
                MAX_INT_SIZE,  # only used in interval representation, currently deactivated
                MAX_MELODY_PITCH_RANGE,  # only used in interval representation, currently deactivated
                REFERENCE_MODE,
                stats,
                MAX_ABS_INT_ERROR_ALLOWED,  # deactivated
                (MAX_INTERVAL2REFERENCE * 2)  # only used in pitch mode
            )

        failed = is_failed["failed"]
        reason = is_failed["reason"]

        # convert back to high register
        if self.participant.var.register == "low":
            target_pitches = [(i + 12) for i in target_pitches]
            sung_pitches = [(i + 12) for i in sung_pitches]
            reference_pitch = reference_pitch + 12

        return {
            "failed": failed,
            "reason": reason,
            "register": self.participant.var.register,
            "max_num_diff_pitches_allowed": MAX_NUM_DIFF_PITCHES_ALLOWED,
            "reference_pitch": reference_pitch,
            "target_pitches": target_pitches,
            "num_target_pitches": len(target_pitches),
            "target_intervals": target_intervals,
            "sung_pitches": sung_pitches,
            "num_sung_pitches": len(sung_pitches),
            "sung_intervals": sung_intervals,
            "sung_intervals2reference": sung_intervals2reference,
            "raw": raw,
            "save_plot": save_plot,
            "stats": stats,
        }


class CustomTrialPractice(CustomTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial_practice"}

    wait_for_feedback = True
    time_estimate = TIME_ESTIMATE_TRIAL - 10

    def gives_feedback(self, experiment, participant):
        return True

    def show_feedback(self, experiment, participant):
        output_analysis = json.loads(self.details["analysis"])
        num_sung_pitches = len(output_analysis["sung_pitches"])
        num_target_pitches = len(output_analysis["target_pitches"])

        if num_sung_pitches == num_target_pitches:
            return InfoPage(
                Markup(
                    f"""
                    <h3>Excellent!</h3>
                    <hr>
                    <br><br>
                    Keep up this performance throughout the experiment and you will get the full bonus.
                    <hr>
                    <img style="width:20%" src="/static/images/happy.png"  alt="happy">
                    """
                ),
                time_estimate=5
            )
        elif num_sung_pitches == (num_target_pitches - 1) or num_sung_pitches == (num_target_pitches + 1):
            return InfoPage(
                Markup(
                    f"""
                    <h3>Ok, but you can do better...</h3>
                    <hr>
                    You sung {num_sung_pitches} out of {num_target_pitches} notes.
                    <br>
                    Please try to do one or more of the following:
                    <ol><li>Sing back the melody as accurately as possible.</li>
                        <li>Leave a silent gap between the notes.</li>
                        <li>Sing each note clearly using the syllable '{SYLLABLE}'.</li>
                        <li>Sing each not for about 1 second each.</li>
                        <li>Make sure you computer microphone is working and you are in a quiet environment.</li>
                    </ol>
                    <br><br>
                    <b><b>If you don't improve your performance, the experiment will terminate.</b></b>
                    <hr>
                    <img style="width:20%" src="/static/images/neutral.png"  alt="neutral">
                    """
                ),
                time_estimate=5
            )
        else:
            return InfoPage(
                Markup(
                    f"""
                    <h3>Bad..</h3>
                    <hr>
                    You sung {num_sung_pitches} out of {num_target_pitches} notes.
                    <br><br>
                    Please try to do one or more of the following:
                    <ol><li>Sing back the melody as accurately as possible.</li>
                        <li>Leave a silent gap between the notes.</li>
                        <li>Sing each note clearly using the syllable {SYLLABLE}.</li>
                        <li>Sing each not for about 1 second each.</li>
                        <li>Make sure you computer microphone is working and you are in a quiet environment.</li>
                    </ol>
                    <br><br>
                    <b><b>If you don't improve your performance, the experiment will terminate.</b></b>
                    <hr>
                    <img style="width:20%" src="/static/images/sad.png"  alt="sad">
                    """
                ),
                time_estimate=5
            )


class CustomNetwork(AudioImitationChainNetwork):
    __mapper_args__ = {"polymorphic_identity": "custom_network"}

    run_async_post_grow_network = False
    s3_bucket = BUCKET_NAME

    if UNCONSTRAINED_NUM_NOTES:
        def make_definition(self):
            return {
                "num_note_options": self.balance_across_networks(NUM_NOTE_OPTIONS)
            }


class CustomNode(AudioImitationChainNode):
    __mapper_args__ = {"polymorphic_identity": "custom_node"}

    def summarize_trials(self, trials: list, experiment, participant):
        sung_intervals2reference = [trial.analysis["sung_intervals2reference"] for trial in trials]
        sung_intervals = [trial.analysis["sung_intervals"] for trial in trials]
        register = [trial.analysis["register"] for trial in trials]

        # retrieve url
        # recording_url = [trial.answer["url"] for trial in trials]
        # recording_url_as_string = "".join([str(item) for item in recording_url])

        reference_pitch = melodies.sample_reference_pitch(
            roving_mean["high"],
            roving_width,
        )

        target_intervals2reference = [mean(x) for x in zip(*sung_intervals2reference)]
        target_intervals = [mean(x) for x in zip(*sung_intervals)]

        if IS_MATLAB_MATCH:
            target_pitches = melodies.convert_interval_sequence_to_absolute_pitches(
                intervals=target_intervals,
                reference_pitch=reference_pitch,
                reference_mode="previous_note",
            )
        else:
            target_pitches = melodies.convert_intervals2reference_to_absolute_pitches(
                intervals2refernece=target_intervals2reference,
                reference_pitch=reference_pitch
            )

        return dict(
            reference_pitch=reference_pitch,
            register=register.pop(0),
            target_pitches=target_pitches,
            target_intervals=target_intervals,
            target_intervals2reference=target_intervals2reference,
            num_target_pitches=len(target_pitches),
            trial_type="node_trial"
            # recording_url=recording_url_as_string
        )


class CustomSource(AudioImitationChainSource):
    __mapper_args__ = {"polymorphic_identity": "custom_source"}

    def generate_seed(self, network, experiment, participant):
        if self.network.phase == "practice_feedback" or self.network.phase == "practice_test":
            max_interval2reference = 4.5
            max_interval_size = MAX_ABS_INT_ERROR_ALLOWED
            num_notes = NUM_NOTES
            if UNCONSTRAINED_NUM_NOTES:
                num_notes = melodies.sample_num_pitches(4, 6)
        else:
            max_interval2reference = MAX_INTERVAL2REFERENCE
            max_interval_size = MAX_ABS_INT_ERROR_ALLOWED
            num_notes = NUM_NOTES
            if UNCONSTRAINED_NUM_NOTES:
                num_notes = network.definition["num_note_options"]

        reference_pitch = melodies.sample_reference_pitch(
            roving_mean["high"],
            roving_width,
        )

        if REFERENCE_MODE == "pitch_mode":
            target_pitches = melodies.sample_absolute_pitches(
                reference_pitch=reference_pitch,
                max_interval2reference=max_interval2reference,
                num_pitches=num_notes
            )
            target_intervals = melodies.convert_absolute_pitches_to_interval_sequence(target_pitches, "previous_note")
        else:
            target_intervals = melodies.sample_interval_sequence(
                n_int=NUM_INT,
                max_interval_size=MAX_INT_SIZE,  # deactivated
                max_melody_pitch_range=MAX_MELODY_PITCH_RANGE,  # deactivated
                discrete=False,
                reference_mode=REFERENCE_MODE
            )
            target_pitches = melodies.convert_interval_sequence_to_absolute_pitches(
                intervals=target_intervals,
                reference_pitch=reference_pitch,
                reference_mode=REFERENCE_MODE,
            )

        target_intervals2reference = melodies.convert_absolute_pitches_to_intervals2reference(
            target_pitches, reference_pitch)

        return dict(
            register="high",  # all melodies are generated in the high register
            reference_pitch=reference_pitch,
            max_interval2reference=max_interval2reference,
            max_interval_size=max_interval_size,
            target_pitches=target_pitches,
            target_intervals=target_intervals,
            target_intervals2reference=target_intervals2reference,
            num_target_pitches=num_notes,
            trial_type="source_trial",
            reference_mode=REFERENCE_MODE
        )


class SingingImitationTrialMakerPractice(AudioImitationChainTrialMaker):
    performance_check_type = "performance"
    performance_check_threshold = 0
    give_end_feedback_passed = False


class SingingImitationTrialMakerTest(AudioImitationChainTrialMaker):
    performance_check_type = "performance"
    performance_check_threshold = 0.60
    give_end_feedback_passed = False


class ImitationChainTrialMakerMain(AudioImitationChainTrialMaker):
    give_end_feedback_passed = False
    performance_check_type = "performance"
    performance_check_threshold = DESIGN_PARAMS["performance_threshold_block1"]

    def find_networks(self, participant, experiment, ignore_async_processes=False):
        # get available networks
        old_networks = super().find_networks(participant, experiment, ignore_async_processes)
        new_networks = []
        for network in old_networks:
            # get available infor per network
            infos = Info.query.filter_by(network_id=network.id).all()
            max_degree = max([info.degree for info in infos], default=0)
            # get N failed infor in the most recent degree
            num_failed_infos = sum([info.failed for info in infos if
                                    info.degree == max_degree])

            if num_failed_infos < MAX_NUM_FAILED_TRIALS_ALLOWED:
                new_networks.append(network)
            else:
                logger.info("****** Network {} failed ******".format(network.id))
                logger.info("****** Too many failed infos: {} ******".format(num_failed_infos))

        return new_networks

    def check_fail_logic(self):
        return join(
            InfoPage(
                Markup(f"""
                    <h3>You have completed the experiment</h3>
                    <br><br>
                    Thank you for your participation!
                    """
                       ),
                time_estimate=5),
            SuccessfulEndPage())


singing_practice = join(
    InfoPage("We can now start with the main singing task, please pay attention to the instructions.", time_estimate=2),
    InfoPage(
        Markup(f"""
        <h3>Practice Singing</h3>
        <hr>
        In each trial, you will hear a melody composed of {NUM_NOTES} notes.</b></b>
        <br><br>
        Your goal is to sing back the melody as accurately as possible, 
        singing each note to the syllable '{SYLLABLE}'.
        <br><br>
        <hr>
        Click <b>next</b> to start the practice.
        """
               ),
        time_estimate=3
    ),
    SingingImitationTrialMakerPractice(
        id_="sing_feedback",
        network_class=CustomNetwork,
        trial_class=CustomTrialPractice,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_feedback",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_feedback"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=False,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
    InfoPage(
        Markup(f"""
        <h3>Singing test</h3>
        <hr>
        You will now take a singing test. The task is the same as before.
        <hr>
        """
               ),
        time_estimate=3
    ),
    InfoPage(
        Markup(f"""
        <h3>Attention</h3>
           <hr>
           We will monitor your performance after each trial.<br><br> 
           <b><b>If your performance is not good, the experiment will terminate earlier.</b></b>
           <hr>
           Click <b>next</b> to start the test.
           """
               ),
        time_estimate=3
             ),
    SingingImitationTrialMakerTest(
        id_="sing_test",
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase="practice_test",
        chain_type="within",
        num_iterations_per_chain=1,
        num_trials_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_participant=DESIGN_PARAMS["num_trials_practice_test"],
        num_chains_per_experiment=None,
        trials_per_node=1,
        balance_across_chains=True,
        check_performance_at_end=True,
        check_performance_every_trial=False,
        recruit_mode="num_participants",
        target_num_participants=0,
        wait_for_networks=True
    ),
)


def copy_main_trialmaker(id, phase, num_trials, num_chains_per_exp, num_chains_per_participant):
    trialmaker = ImitationChainTrialMakerMain(
        id_=id,
        network_class=CustomNetwork,
        trial_class=CustomTrial,
        node_class=CustomNode,
        source_class=CustomSource,
        phase=phase,
        chain_type=DESIGN_PARAMS["chain_type"],
        num_trials_per_participant=num_trials,
        num_iterations_per_chain=DESIGN_PARAMS["num_iterations_per_chain"],
        num_chains_per_participant=num_chains_per_participant,  # only relevant if chain_type="within"
        num_chains_per_experiment=num_chains_per_exp,  # only relevant if chain_type="across"
        trials_per_node=DESIGN_PARAMS["trials_per_node"],
        balance_across_chains=DESIGN_PARAMS["balance_across_chains"],
        check_performance_at_end=True,
        check_performance_every_trial=False,
        propagate_failure=False,
        recruit_mode=DESIGN_PARAMS["recruit_mode"],
        target_num_participants=DESIGN_PARAMS["target_num_participants"],
        allow_revisiting_networks_in_across_chains=DESIGN_PARAMS["repeat_same_chain"],
    )
    return trialmaker


singing_block1 = copy_main_trialmaker(
    "singing_block1",
    "experiment_block1",
    DESIGN_PARAMS["num_trials_per_participant_block1"],
    DESIGN_PARAMS["num_chains_per_exp_block1"],
    DESIGN_PARAMS["num_chains_per_participant"]
)

# singing_block2 = copy_main_trialmaker(
#     "singing_block2",
#     "experiment_block2",
#     DESIGN_PARAMS["num_trials_per_participant_block2"],
#     DESIGN_PARAMS["num_chains_per_exp_block2"],
#     DESIGN_PARAMS["num_chains_per_participant"]
# )


########################################################################################################################
# Instructions
########################################################################################################################
instructions_block1 = join(
    InfoPage(
        Markup(
            f"""
            <h3>Singing Instructions</h3>
            <hr>
            This is the main singing task: you will hear melodies and your goal is to sing them back to 
            the syllable {SYLLABLE}.
            <br><br>
            You will take a total of {DESIGN_PARAMS["num_trials_per_participant_block1"]} trials.
            <br><br>
            <hr>
            """
        ),
        time_estimate=5,
    ),
    InfoPage(Markup(f"""
           <h3>Attention</h3>
           <hr>
            We will analyse your performance after each trial:
            <br><br>
            <b><b>If your performance is bad, the experiment will terminate.</b></b> 
            <br><br>
            <b><b>The best strategy is to sing carefully and as accurately as possible in all trials.</b></b>
            <hr>
            Click <b>next</b> to start singing!
            """
                    ),
             time_estimate=3
             )
)


welcome = InfoPage(
    Markup(
        """
        <h3>The Singing Experiment</h3>
        <hr>
        In this experiment, you will create music by singing melodies.
        <hr>
        <img style="width:40%" src="/static/images/singing-together.jpeg"  alt="singing-together text-align: center">
        """
    ),
    time_estimate=3
)


headphones_warning = InfoPage(
    Markup(
        """
        <h3>Attention</h3>
        <hr>
        <b><b>You must use WIRED headphones or earplugs with working microphone</b></b>. 
        <br><br>
        Wireless or Bluetooth devices will not work. If you do not use wired headphones/ earplugs, 
        the experiment will terminate early.
        <hr>
        <img style="width:75%" src="/static/images/headphones.png"  alt="headphones text-align: center">
        """
    ),
    time_estimate=3
)


########################################################################################################################
# Timeline
########################################################################################################################
if DEBUG:
    class Exp(psynet.experiment.Experiment):
        timeline = Timeline(
            PreDeployRoutine(
                "make_bucket_public",
                make_bucket_public,
                {"bucket_name": BUCKET_NAME}
            ),
            PreDeployRoutine(
                "prepare_s3_bucket_for_presigned_urls",
                prepare_s3_bucket_for_presigned_urls,
                {"bucket_name": BUCKET_NAME, "public_read": True, "create_new_bucket": True}
            ),
            NoConsent(),
            welcome,
            CodeBlock(lambda participant: participant.var.set("register", "low")),
            instructions_block1,
            singing_block1,
            InfoPage(Markup("Congratulations, you finished the main singing task"), time_estimate=2),
            SuccessfulEndPage(),
        )
        def __init__(self, session=None):
            super().__init__(session)
            self.initial_recruitment_size = INITIAL_RECRUITMENT_SIZE
else:
    class Exp(psynet.experiment.Experiment):
        # Only if using cap-recruit!
        # variables = {"wage_per_hour": 15.0}

        timeline = Timeline(
            PreDeployRoutine(
                "make_bucket_public",
                make_bucket_public,
                {"bucket_name": BUCKET_NAME}
            ),
            PreDeployRoutine(
                "prepare_s3_bucket_for_presigned_urls",
                prepare_s3_bucket_for_presigned_urls,
                {"bucket_name": BUCKET_NAME, "public_read": True, "create_new_bucket": True}
            ),
            # NoConsent(),
            MainConsent(),
            OpenScienceConsent(),
            welcome,
            headphones_warning,
            HeadphoneTest(),
            InfoPage("You passed the headphone screening task! Congratulations.", time_estimate=2),
            SingingCalibration(),
            ToneJSVolumeTest(
                timbre=TIMBRE,
                note_duration=note_duration_tonejs,
                note_silence=note_silence_tonejs,
            ),
            SingingPerformanceTest(
                performance_threshold=5,  # 10 trials in total
                timbre=TIMBRE,
                note_duration=note_duration_tonejs,
                note_silence=note_silence_tonejs,
                roving_width=roving_width,
                roving_mean_low=roving_mean["low"],
                roving_mean_high=roving_mean["high"],
                trial_maker_id="performance_test"
            ),
            conditional(
                label="assign_register",
                condition=lambda experiment, participant: participant.var.predicted_register == "undefined",
                logic_if_true=CodeBlock(
                    lambda experiment, participant: participant.var.set("register", random.choice(["low", "high"]))),
                logic_if_false=CodeBlock(lambda experiment, participant: participant.var.set("register",
                                                                                             participant.var.predicted_register)),
                fix_time_credit=False
            ),
            BasicDemography(),
            singing_practice,
            InfoPage(Markup("Congratulations, we now move on to the main singing task."), time_estimate=3),
            instructions_block1,
            singing_block1,
            InfoPage(Markup("Congratulations, you finished the main singing task"), time_estimate=2),
            GMSI(label="GMSI_MT", subscales=["Musical Training"]),
            GMSI(label="GMSI_SA", subscales=["Singing Abilities"]),
            Feedback(),
            SuccessfulEndPage(),
        )

        def __init__(self, session=None):
            super().__init__(session)
            self.initial_recruitment_size = INITIAL_RECRUITMENT_SIZE

        # for cap-recruit only
        # @classmethod
        # def extra_parameters(cls):
        #     get_config().register("cap_recruiter_auth_token", str, [], False)
