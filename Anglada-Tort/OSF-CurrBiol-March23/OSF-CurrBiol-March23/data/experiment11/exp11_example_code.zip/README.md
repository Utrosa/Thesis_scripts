# ising-long-pitch-repository

This repository contains all the experimental data and code used for experiments using iterated-singing with 10 iterations and pitch representation

## List of Experiments (pre-cogsci)

1. Study 1. ising (pitch mode), interval = 2 (max size = 7.5), timbre = piano, iterations = 10 (across): `ising-long-pitch/data-mat-ising-long1`.
    - full chains = 120
2. Study 2. ising (pitch mode), interval = 4 (max size = 7.5), timbre = piano, iterations = 30 (across): `ising-long-pitch/data-mat-ising-long2`.
    - 30 iterations
    - Piano / raw
    - full chains = 40
3. Study 3. ising (pitch mode), interval = free (max size = 7.5), timbre = piano, iterations = 10 (across): `ising-long-pitch/data-mat-ising-unc1`.
    - Unconstrained number of notes, balancing netowrks from 4 to 12
    - full chains = 144


## List of Experiments (post-cogsci)
4. iterated-singing (pitch mode), interval = 2 (max size = 9.5), timbre = complex_long, iterations = 10 (across): `ising-long-pitch/data-ising-timbre1`.
    - Trying new timbre, long version
    - Also exploring the new singing perfomrance to determine particiapnts singing register (roving_widht = 2.5)
 5. iterated-singing (pitch mode), interval = 2 (max size = 9.5), timbre = complex_short, iterations = 10 (across): `ising-long-pitch/data-ising-timbre2`.
    - Trying new timbre, short version (McDermott match)
    - Also exploring the new singing perfomrance to determine particiapnts singing register (roving_widht = 6)
 6. iterated-singing (pitch mode), interval = 2 (max size = 9.5), timbre = sustain_short_isi_long, iterations = 10 (across): `ising-long-pitch/data-ising-timbre3`.
    - Trying new timbre, short sustain (~0.4s) and long ISI (0.8s)
    - Also: assign participants' register automatically
 7. iterated-singing (pitch mode), interval = 2 (max size = 9.5), timbre = sustain_short_isi_long,  iterations = 10 (within): `ising-long-pitch/data-ising-within1-5iter`.
    - Same as above but first pilot using within-chains desin
    - **problem**: I did not rove at all
 8. iterated-singing (pitch mode), interval = 2 (max size = 9.5), timbre = sustain_short_isi_long,  iterations = 5 (within): `ising-long-pitch/data-ising-within-batch1-5iter`.
    - Same as above but roving (+/- 2.5 at each node, moving melody up and down)
    - I only used 5 iterations so I could run more chains ~240
    - **problem**: roving was wrong... I need to impement a new way using reference_pitch
 9. iterated-singing (pitch mode), interval = 2 (max size = 7.5), timbre = sustain_mid_isi_long,  iterations = 10 (within): `ising-long-pitch/data-ising-within-batch1`.
    - 160 chains
 10. iterated-singing (pitch mode), interval = 2 (max size = 7.5), timbre = sustain_mid_isi_long,  iterations = 10 (across): `ising-long-pitch/data-ising-btw-batch1`.
    - 160 chains
 11. iterated-singing (pitch mode), interval = 2 (max size = 10), timbre = sustain_mid_isi_long,  iterations = 10 (across): `ising-long-pitch/data-btw-batch1-200`.
    - 200 chains
    - max_intercal2reference = 10
 12. iterated-singing (pitch mode), interval = 4 (max size = 10), timbre = sustain_mid_isi_long,  iterations = 10 (across): `ising-long-pitch/data-btw-5tones-b1-failed`.
    - 200 chains
    - max_intercal2reference = 10
    - max_abs_int_allowed = 8.5
    - FAILED = not enough people could complete

## Datasets included in paper
 13. `data-btw-3tones-b1`
     - iterated sining 2 int + across + pitch mode + new timbre + 10 iterations:
     - 200 chains
     - max_abs_int_)allowed = 5.5
     - max_intercal2reference = 10
 14. `data-btw-3tones-b2`
     - same as 13 but second batch
 15. `data-wth-3tones-b2`
     - same as 13 and 14 but within-chains design
 16. `data-btw-3tones-in1`
     - same as 13 and 14 but recruiting in india

