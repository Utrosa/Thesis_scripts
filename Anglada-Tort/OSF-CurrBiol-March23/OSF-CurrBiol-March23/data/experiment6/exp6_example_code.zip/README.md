# Melodic consonance experiments

### Apps
- `mat-ising-melcon1` —> continous sampling 5K (piano)
- `mat-ising-melcon2` —> rounding sampling at integer semitones 5K (piano)
- `mat-ising-melcon3` —>  rounding at 0.25 semitones 3K (piano)
- `melcon-complex-long1` —> blocking by refere_pitch, complex_long timbre, 2500 stimuli
- `melcon-timbre1`  —> blocking by refere_pitch, complex_long timbre, 3K (female register)
- `melcon-timbre2`  —> blocking by refere_pitch, complex_long timbre, 3K (female register)