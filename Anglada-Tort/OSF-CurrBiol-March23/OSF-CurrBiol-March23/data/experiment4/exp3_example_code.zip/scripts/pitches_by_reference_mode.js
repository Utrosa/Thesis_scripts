pitches_by_reference_mode = function(init_intervals, selected_indx, reference_mode, reference_pitch ){
    var current = parseFloat(reference_pitch);
    var freqs = [];
    var intervals = [0].concat(eval(init_intervals));
    var input = parseFloat(info.outputValue);
    intervals[parseFloat(selected_indx)+1] = input;

    if (reference_mode == "first_note"){
        for(i=0;i<intervals.length;i++){
            freqs=freqs.concat([current+intervals[i]])
        }
    }else if (reference_mode == "previous_note") {
        for(i=0;i<intervals.length;i++){
            current+=intervals[i]
            freqs=freqs.concat([current])
        }
    }

    for(i=0;i<intervals.length;i++){
        stimulus.notes[i].pitches = [freqs[i]]
    };
}
