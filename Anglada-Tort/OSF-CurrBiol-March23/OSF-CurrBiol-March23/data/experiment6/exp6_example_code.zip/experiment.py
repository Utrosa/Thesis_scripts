##########################################################################################
#### Imports
##########################################################################################
from dallinger.config import get_config
import logging
import numpy as np
import pandas as pd
import random
from flask import Markup
from statistics import mean
from sqlalchemy import exc as sa_exc
from psynet.demography.gmsi import GMSI
from psynet.consent import MainConsent, AudiovisualConsent, NoConsent, MTurkStandardConsent
import psynet.experiment
from psynet.timeline import (
    Timeline,
    join,
    Event,
    switch,
    CodeBlock
)
from psynet.js_synth import JSSynth, Note, InstrumentTimbre, HarmonicTimbre
from psynet.page import (
    InfoPage,
    SuccessfulEndPage,
    VolumeCalibration
)
from psynet.trial.static import (
    StimulusSpec,
    StimulusSet,
    StaticTrialMaker,
    StaticTrial
)
from psynet.modular_page import ModularPage, NAFCControl
from psynet.prescreen import HeadphoneTest
# sing4me
from sing_experiments import params
from sing_experiments.resources import (
    ToneJSVolumeTest,
    select_timbre,
)
from sing_experiments.questionnaire import BasicDemography, Feedback
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__file__)


########################################################################################################################
# Global parameters
########################################################################################################################
DEBUG = False
BLOCKING = False
TIME_ESTIMATE_TRIAL = 4
NUM_NOTES = 2

PATH_TO_DATA = "sampling/melodic_consonance_5K_batch1.csv"
# PATH_TO_DATA = "sampling/melodic_consonance_5K_batch2.csv"
# PATH_TO_DATA = "sampling/melodic_consonance_5K_batch3.csv"

# sing4me
config = params.singing_2intervals  # 2 intervals
# config = params.singing_long_melodies  # 4 intervals

# timbre
# select timbre: piano, complex_short_ISI_long, complex_long_ISI_long, complex_short_ISI_short, complex_mid_ISI_long
note_duration_tonejs, note_silence_tonejs, TIMBRE = select_timbre("complex_mid_ISI_long")

if DEBUG:
    INITIAL_RECRUITMENT_SIZE = 1
    CONFIG = {
        "num_experiment_trials": 5,  # PER BLOCK!
        "num_repeat_trials": 2,
        "num_blocks": 2,
        "num_experiment_trials_practice": 2
    }
else:
    INITIAL_RECRUITMENT_SIZE = 30
    if BLOCKING:
        CONFIG = {
            "num_experiment_trials": 15,  # PER BLOCK!
            "num_repeat_trials": 5,
            "num_blocks": 4,
            "num_experiment_trials_practice": 2
        }
    else:
        CONFIG = {
            "num_experiment_trials": 50,  # PER BLOCK!
            "num_repeat_trials": 10,
            "num_blocks": 1,
            "num_experiment_trials_practice": 2
        }


def make_timeline():
    return Timeline(
        MainConsent(),
        CodeBlock(lambda experiment: experiment.var.set("show_progress_bar", False)),
        headphones_warning,
        ToneJSVolumeTest(timbre=TIMBRE),
        HeadphoneTest(),
        InfoPage("You passed the headphone screening task! Congratulations.", time_estimate=3),
        instructions(),
        make_experiment_trials(),
        BasicDemography(),
        GMSI(label="GMSI_MT", subscales=["Musical Training"]),
        GMSI(label="GMSI_SA", subscales=["Singing Abilities"]),
        Feedback(),
        SuccessfulEndPage()
    )


def instructions():
    return join(
        InfoPage(Markup(
            """
            <h3>Instructions - Main Task</h3>
            <hr>
            In each trial of this experiment you will be presented with a word and a sound. 
            Your task will be to judge how well the sound matches the word.
            <br><br>
            You will have seven response options, ranging from 'Completely Disagree' to 'Completely Agree'.
            <br>Choose the one you think is most appropriate.
            <hr>
            """
        ),
            time_estimate=5
        ),
        InfoPage(
            Markup(
                """
                <h3>Attention</h3>
                <hr>
                The quality of your responses will be automatically monitored,
                and you will receive a bonus at the end of the experiment
                in proportion to your quality score. 
                <br><br>
                <b><b>The best way to achieve a high score is to concentrate and 
                give each trial your best attempt.</b></b>
                """
            ),
            time_estimate=5
        ),
        InfoPage(
            Markup(
                f"""
                You will take up to
                {CONFIG['num_experiment_trials'] * CONFIG["num_blocks"] + CONFIG['num_repeat_trials']} trials.
                <br><b><b>Remember to pay careful attention in order to get the best bonus!</b></b>
                <br><br>
                Pres <b><b>Next</b></b> to start the rating task.
                """
            ),
            time_estimate=5
        ),
    )


def get_stimulus_set():
    import pandas as pd
    import json
    df = pd.read_csv(PATH_TO_DATA)  # Change to desired stimuli file
    stimuli = [
        StimulusSpec(
            {
                "melodies": {
                    "pitches": json.loads(record["pitches"]),
                    "target": record["target"],
                    # "block": record.get("block_str") if record.get("block_str") else "default",
                },
            },
            phase="experiment",
            # block=record.get("block_str") if record.get("block_str") else "default"
        )
        for record in df.to_dict("records")
    ]
    return StimulusSet("mel_stimuli", stimuli)


nafc_choices = [
    (1, "(1) Completely Disagree"),
    (2, "(2) Strongly Disagree"),
    (3, "(3) Disagree"),
    (4, "(4) Neither Agree nor Disagree"),
    (5, "(5) Agree"),
    (6, "(6) Strongly Agree"),
    (7, "(7) Completely Agree")
]

headphones_warning = InfoPage(
    Markup(
        """
        <h3>Attention</h3>
        <hr>
        <b><b>You must use headphones or earplugs</b></b>. 
        <br><br>
        If you do not, the experiment will terminate early.
        <hr>
        <img style="width:75%" src="/static/images/headphones.png"  alt="headphones text-align: center">
        """
    ),
    time_estimate=3
)


class RatingControl(NAFCControl):
    def __init__(self):
        super().__init__(
            choices=[x[0] for x in nafc_choices],
            labels=[x[1] for x in nafc_choices],
            arrange_vertically=True
            # min_width="125px"
        )

    def format_answer(self, raw_answer, **kwargs):
        return int(raw_answer)


class CustomTrial(StaticTrial):
    __mapper_args__ = {"polymorphic_identity": "custom_trial"}

    time_estimate = TIME_ESTIMATE_TRIAL

    def show_trial(self, experiment, participant):
        current_trial = self.position + 1
        if self.phase == "practice":
            total_num_trials = CONFIG['num_experiment_trials_practice']
        else:
            total_num_trials = CONFIG['num_experiment_trials'] * CONFIG["num_blocks"] + CONFIG['num_repeat_trials']
        show_current_trial = f'Trial number {current_trial} out of {total_num_trials} trials.'

        # import rpdb
        # rpdb.set_trace()

        melody = self.definition['melodies']

        return ModularPage(
            "custom_trial",
            JSSynth(
                Markup(
                    f"""
                       How well does the sound match the following word (pay attention to subtle differences):
                       <b><b>{melody['target']}</b></b><br>
                       <br><br>
                       {show_current_trial}
                       """
                ),
                sequence=[Note(x) for x in melody['pitches']],
                timbre=TIMBRE,
                default_duration=note_duration_tonejs,
                default_silence=note_silence_tonejs
            ),
            RatingControl(),
            events={
                "promptStart": Event(is_triggered_by="trialStart"),
                "responseEnable": Event(is_triggered_by="promptEnd", delay=1),
                "submitEnable": Event(is_triggered_by="promptEnd", delay=1)
            },
        )


class CustomTrialMaker(StaticTrialMaker):
    give_end_feedback_passed = False
    performance_threshold = -1.0

    num_blocks = CONFIG["num_blocks"]

    if BLOCKING:
        def choose_block_order(self, experiment, participant):
            blocks = self.stimulus_set.blocks
            random.shuffle(blocks)
            return blocks[0:self.num_blocks]

    def compute_bonus(self, score, passed):
        if self.phase == "practice":
            return 0.0
        elif self.phase == "experiment":
            if score is None:
                return 0.0
            else:
                return min(max(0.0, 0.5 * score), 0.5)
        else:
            raise NotImplementedError


def make_experiment_trials():
    return CustomTrialMaker(
        id_="main_experiment",
        trial_class=CustomTrial,
        phase="experiment",
        stimulus_set=get_stimulus_set(),
        recruit_mode="num_trials",
        target_num_participants=None,
        target_num_trials_per_stimulus=1,
        max_trials_per_block=CONFIG["num_experiment_trials"],
        max_unique_stimuli_per_block=CONFIG["num_experiment_trials"],
        allow_repeated_stimuli=False,
        # active_balancing_within_participants=True,
        # active_balancing_across_participants=True,
        check_performance_at_end=False,
        check_performance_every_trial=False,
        fail_trials_on_premature_exit=True,
        fail_trials_on_participant_performance_check=False,
        num_repeat_trials=CONFIG["num_repeat_trials"]
    )


class Exp(psynet.experiment.Experiment):
    # variables = {"wage_per_hour": 15.0}  # Only if using cap-recruit!

    timeline = make_timeline()

    def __init__(self, session=None):
        super().__init__(session)
        self.initial_recruitment_size = INITIAL_RECRUITMENT_SIZE


    # for cap-recruit only
    # @classmethod
    # def extra_parameters(cls):
    #     get_config().register("cap_recruiter_auth_token", str, [], False)

    @property
    def ad_payment_information(self):
        return f"""
            In this HIT you would receive a bonus of about 9$ per hour.
            <br>
            In some cases, the experiment may finish early: this is not an error, and there is no need to write to us.
            <br>
            In this case you will be paid in proportion to the amount of the experiment that you completed.
            """
